import React from 'react';

export type Language = 'en' | 'es';
export type UserRole = 'user' | 'admin' | 'guest';

export interface TeamMember {
  id: string;
  name: string;
  email: string;
  role: 'editor' | 'viewer';
  avatarUrl?: string;
  status: 'active' | 'pending';
}

export interface SocialLink {
  platform: 'facebook' | 'instagram' | 'linkedin' | 'x' | 'tiktok';
  username: string;
}

export interface Project {
  id: string;
  name: string;
  industry?: string;
  createdAt: number;
  
  // Project Identity (Public facing data)
  logoUrl?: string;
  brandColors: string[]; // Changed from single themeColor to array of 3
  website?: string;
  email?: string; // Public contact email
  phone?: string; // Legacy
  whatsapp?: string; // Stored as full string, UI handles split
  address?: string;
  location?: { lat: number; lng: number }; // For Map selection
  
  socials: SocialLink[]; // Changed to dynamic array

  // Resources
  installedAppIds: string[];
  assignedMemberIds: string[];
}

export interface UserProfile {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  language: Language;
  phone?: string; 
  
  // Account Owner Data
  subscriptionPlan: 'free' | 'pro' | 'enterprise';
  onboardingCompleted: boolean; 
  
  // Multi-project & Team architecture
  projects: Project[]; 
  teamMembers: TeamMember[]; 

  integrations?: {
    emailItId?: string;
  }
}

export interface ServiceApp {
  id: string;
  name: string;
  description: string;
  icon: React.ReactNode;
  url: string; 
  status: 'active' | 'beta' | 'coming_soon';
  requiresPro: boolean;
}

export enum AuthView {
  LOGIN,
  REGISTER,
  GUEST
}