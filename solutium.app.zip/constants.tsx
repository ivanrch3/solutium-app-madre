import React from 'react';
import { ServiceApp } from './types';

// --- MASTER DESIGN MEMORY ---
// Centralized source of truth for UI consistency.
// All components should reference these classes via strict components.

export const THEME_CLASSES = {
  button: {
    base: "inline-flex items-center justify-center px-4 py-2 border rounded-lg font-medium transition-all focus:outline-none focus:ring-2 focus:ring-offset-2 disabled:opacity-50 disabled:cursor-not-allowed shadow-sm",
    variants: {
      primary: "border-transparent text-white bg-solutium-blue hover:bg-solutium-dark focus:ring-solutium-blue",
      secondary: "border-slate-300 text-slate-700 bg-white hover:bg-slate-50 focus:ring-indigo-500",
      danger: "border-transparent text-white bg-red-600 hover:bg-red-700 focus:ring-red-500",
      ghost: "border-transparent text-slate-500 hover:bg-slate-100 hover:text-slate-700",
      accent: "border-transparent text-solutium-dark bg-solutium-yellow hover:bg-yellow-300 focus:ring-yellow-400"
    },
    sizes: {
      sm: "text-xs px-2.5 py-1.5",
      md: "text-sm px-4 py-2",
      lg: "text-base px-6 py-3"
    }
  },
  input: {
    base: "block w-full px-4 py-3 rounded-lg border text-slate-900 placeholder-slate-400 bg-slate-50 focus:bg-white focus:outline-none focus:ring-0 transition-all duration-200 ease-in-out sm:text-sm shadow-sm",
    label: "block text-sm font-medium text-slate-700 mb-2 ml-1",
    error: "border-red-300 text-red-900 placeholder-red-300 focus:border-red-500 bg-red-50"
  },
  card: {
    base: "bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden"
  },
  layout: {
    pageHeader: "mb-8 border-b border-slate-200 pb-4"
  }
};

// --- ICONS ---
export const Icons = {
  Grid: () => <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2V6zM14 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V6zM4 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2v-2zM14 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2v-2z" /></svg>,
  WebBuilder: () => <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.75 17L9 20l-1 1h8l-1-1-.75-3M3 13h18M5 17h14a2 2 0 002-2V5a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" /></svg>,
  Invoice: () => <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" /></svg>,
  Calendar: () => <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" /></svg>,
  Code: () => <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 20l4-16m4 4l4 4-4 4M6 16l-4-4 4-4" /></svg>,
  Settings: () => <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" /></svg>,
  LogOut: () => <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" /></svg>
};

// --- INDUSTRIES ---
export const INDUSTRIES = {
  en: ['Technology', 'Retail', 'Health', 'Consulting', 'Education', 'Construction', 'Food & Beverage', 'Art & Design', 'Other'],
  es: ['Tecnología', 'Comercio', 'Salud', 'Consultoría', 'Educación', 'Construcción', 'Gastronomía', 'Arte y Diseño', 'Otro']
};

// --- DOMAINS & PORTS CONFIGURATION ---
// Determines the URL based on the current environment.

// 1. Detect if we are running locally
// IMPROVED: Now checks for specific hostnames OR if a port is explicitly defined (common in dev like :3000, :5173)
const IS_LOCALHOST = typeof window !== 'undefined' && (
    window.location.hostname === 'localhost' || 
    window.location.hostname === '127.0.0.1' ||
    window.location.port !== '' // If a port exists, assume Local/Dev mode
);

// 2. Detect if we are in the staging environment
const IS_STAGING = typeof window !== 'undefined' && window.location.hostname.includes('staging');

export const DOMAINS = {
    // If Localhost: Point to Ports 3001, 3002, etc.
    // If Staging: Point to *.staging.solutium.app
    // If Prod: Point to *.solutium.app
    
    INVOICER: IS_LOCALHOST 
        ? 'http://localhost:3001' 
        : (IS_STAGING ? 'https://invoice.staging.solutium.app' : 'https://invoice.solutium.app'),
        
    WEB_BUILDER: IS_LOCALHOST 
        ? 'http://localhost:3002' 
        : (IS_STAGING ? 'https://builder.staging.solutium.app' : 'https://builder.solutium.app'),
        
    BOOKING: IS_LOCALHOST 
        ? 'http://localhost:3003' 
        : (IS_STAGING ? 'https://booking.staging.solutium.app' : 'https://booking.solutium.app')
};

// --- AVAILABLE APPS REGISTRY ---
export const AVAILABLE_APPS: ServiceApp[] = [
  {
    id: 'web-builder',
    name: 'SiteCrafter',
    description: 'Build a stunning website in minutes. No code required.',
    icon: <Icons.WebBuilder />,
    url: DOMAINS.WEB_BUILDER,
    status: 'coming_soon',
    requiresPro: false
  },
  {
    id: 'invoicer',
    name: 'ProForma Invoicer',
    description: 'Create professional quotes and invoices that get you paid faster.',
    icon: <Icons.Invoice />,
    url: DOMAINS.INVOICER, // This now dynamically points to localhost:3001 when local
    status: 'active',
    requiresPro: false
  },
  {
    id: 'booking',
    name: 'TimeSync',
    description: 'Manage appointments and client bookings effortlessly.',
    icon: <Icons.Calendar />,
    url: DOMAINS.BOOKING,
    status: 'coming_soon',
    requiresPro: true
  }
];