import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { Icons, INDUSTRIES } from '../constants';
import { Input } from './Input';
import { Button } from './Button';

interface LayoutProps {
  children: React.ReactNode;
  activeTab: string;
  onNavigate: (tab: string) => void;
}

const Layout: React.FC<LayoutProps> = ({ children, activeTab, onNavigate }) => {
  const { user, currentProject, switchProject, createProject, logout, t, currentLang } = useAuth();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isProjectMenuOpen, setIsProjectMenuOpen] = useState(false);
  
  // Navigation Protection State
  const [pendingNavigation, setPendingNavigation] = useState<{ type: 'tab' | 'project' | 'logout', target: string } | null>(null);
  const [showUnsavedModal, setShowUnsavedModal] = useState(false);

  // Create Project Modal State
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [newProjectName, setNewProjectName] = useState('');
  const [newProjectIndustry, setNewProjectIndustry] = useState('');
  const [customIndustry, setCustomIndustry] = useState('');

  const navItems = [
    { id: 'dashboard', label: t.dashboard, icon: Icons.Grid },
    { id: 'portfolio', label: t.portfolio, icon: Icons.WebBuilder },
  ];

  if (user?.role === 'admin') {
    navItems.push({ id: 'tech-roadmap', label: t.techRoadmap, icon: Icons.Code });
    navItems.push({ id: 'admin-console', label: t.adminConsole, icon: Icons.Settings });
  }

  // Helper to check dirtiness
  const hasUnsavedChanges = (): boolean => {
      // @ts-ignore
      return window.hasUnsavedChanges === true;
  };

  const executeNavigation = (type: 'tab' | 'project' | 'logout', target: string) => {
      if (type === 'tab') {
          onNavigate(target);
      } else if (type === 'project') {
          switchProject(target);
      } else if (type === 'logout') {
          logout();
          localStorage.removeItem('solutium_active_tab');
      }
      setIsMobileMenuOpen(false);
      setIsProjectMenuOpen(false);
      setShowUnsavedModal(false);
      setPendingNavigation(null);
  };

  const handleDiscardAndNavigate = () => {
    // CRITICAL FIX: Explicitly clear the dirty flag to prevent the modal from reappearing
    // @ts-ignore
    window.hasUnsavedChanges = false;

    if (pendingNavigation) {
        executeNavigation(pendingNavigation.type, pendingNavigation.target);
    }
  };

  const attemptNavigation = (type: 'tab' | 'project' | 'logout', target: string) => {
      if (hasUnsavedChanges()) {
          setPendingNavigation({ type, target });
          setShowUnsavedModal(true);
      } else {
          executeNavigation(type, target);
      }
  };

  const handleCreateProjectClick = (e: React.MouseEvent) => {
      e.stopPropagation();
      if (hasUnsavedChanges()) {
          // We don't support blocking modal open, just alert user they should save first or we assume they continue
          if(confirm(t.unsavedChanges)) {
             // @ts-ignore
             window.hasUnsavedChanges = false;
             setShowCreateModal(true);
             setIsProjectMenuOpen(false);
          }
      } else {
          setShowCreateModal(true);
          setIsProjectMenuOpen(false);
      }
  };

  const handleCreateConfirm = () => {
      if (user?.subscriptionPlan === 'free' && user.projects.length >= 3) {
          alert(t.projectLimit + ". " + t.upgradeForMore);
          return;
      }

      if(!newProjectName.trim() || !newProjectIndustry) return;
      const finalIndustry = newProjectIndustry === 'Other' || newProjectIndustry === 'Otro' ? customIndustry : newProjectIndustry;
      createProject(newProjectName, finalIndustry);
      
      setNewProjectName('');
      setNewProjectIndustry('');
      setCustomIndustry('');
      setShowCreateModal(false);
      
      onNavigate('project-settings');
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col md:flex-row font-sans">
      {/* Mobile Header */}
      <div className="md:hidden bg-solutium-dark text-white p-4 flex justify-between items-center">
        <img 
            src="https://solutium.app/solutium-logo-blanco.png" 
            alt="Solutium Logo" 
            className="h-10 w-auto" 
        />
        <button onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}>
          <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" /></svg>
        </button>
      </div>

      {/* Sidebar */}
      <aside className={`fixed md:relative z-20 w-64 bg-solutium-dark text-white h-screen transition-transform transform ${isMobileMenuOpen ? 'translate-x-0' : '-translate-x-full'} md:translate-x-0 flex flex-col shadow-2xl`}>
        <div className="p-6 border-b border-white/10 flex flex-col items-start justify-center min-h-[100px]">
          <div className="w-full flex justify-center md:justify-start">
             <img 
                src="https://solutium.app/solutium-logo-blanco.png" 
                alt="Solutium Logo" 
                className="h-14 w-auto object-contain max-w-full" 
             />
          </div>
        </div>

        {/* Project Switcher */}
        <div className="px-4 py-4 border-b border-white/10">
            <div className="flex items-center gap-2">
                <div className="relative flex-1">
                    <button 
                      onClick={() => setIsProjectMenuOpen(!isProjectMenuOpen)}
                      className="w-full flex items-center justify-between bg-white/10 hover:bg-white/20 p-2 rounded-lg transition-colors border border-white/10"
                    >
                        <div className="flex items-center space-x-2 overflow-hidden">
                            <div className="w-6 h-6 rounded bg-solutium-yellow text-solutium-dark flex items-center justify-center font-bold text-xs shrink-0">
                                {currentProject?.name.charAt(0).toUpperCase() || '+'}
                            </div>
                            <span className="text-sm font-medium truncate text-left">{currentProject?.name || t.createProject}</span>
                        </div>
                        <svg className="w-4 h-4 text-slate-400 shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d={isProjectMenuOpen ? "M5 15l7-7 7 7" : "M19 9l-7 7-7-7"} />
                        </svg>
                    </button>

                    {isProjectMenuOpen && (
                      <div className="absolute top-full left-0 w-full mt-2 bg-white rounded-lg shadow-xl overflow-hidden z-30">
                          <div className="max-h-48 overflow-y-auto">
                            {user?.projects.map(p => (
                                <button
                                    key={p.id}
                                    onClick={() => attemptNavigation('project', p.id)}
                                    className={`w-full text-left px-4 py-2 text-sm text-solutium-dark hover:bg-slate-100 flex items-center justify-between ${currentProject?.id === p.id ? 'bg-blue-50 font-bold' : ''}`}
                                >
                                    <span className="truncate">{p.name}</span>
                                    {currentProject?.id === p.id && <div className="w-2 h-2 rounded-full bg-green-500"></div>}
                                </button>
                            ))}
                          </div>
                          <div className="border-t border-slate-200">
                              <button 
                                type="button"
                                onClick={handleCreateProjectClick}
                                className="w-full text-left px-4 py-2 text-sm text-solutium-blue font-medium hover:bg-slate-50 flex items-center cursor-pointer relative z-40"
                              >
                                  <span className="mr-2">+</span> {t.createProject}
                              </button>
                          </div>
                      </div>
                    )}
                </div>

                <button 
                    onClick={() => attemptNavigation('tab', 'project-settings')}
                    className={`p-2.5 rounded-lg border transition-colors ${activeTab === 'project-settings' ? 'bg-solutium-yellow text-solutium-dark border-solutium-yellow' : 'bg-white/10 border-white/10 text-slate-300 hover:bg-white/20 hover:text-white'}`}
                    title={t.projectSettings}
                >
                    <Icons.Settings />
                </button>
            </div>
        </div>

        <nav className="flex-1 p-4 space-y-2 mt-2">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => attemptNavigation('tab', item.id)}
                className={`w-full flex items-center space-x-3 px-4 py-3 rounded-lg transition-all duration-200 group ${
                  isActive 
                  ? 'bg-solutium-blue text-white shadow-lg border-l-4 border-solutium-yellow' 
                  : 'text-slate-300 hover:bg-white/5 hover:text-white'
                }`}
              >
                <div className={`${isActive ? 'text-solutium-yellow' : 'text-slate-400 group-hover:text-white'}`}>
                  <Icon />
                </div>
                <span className="font-medium tracking-wide">{item.label}</span>
              </button>
            );
          })}
        </nav>

        <div className="p-4 border-t border-white/10 bg-black/20">
            <div 
                onClick={() => attemptNavigation('tab', 'profile')}
                className={`flex items-center space-x-3 mb-2 px-2 py-2 rounded-lg cursor-pointer transition-colors ${activeTab === 'profile' ? 'bg-white/10' : 'hover:bg-white/5'}`}
            >
                <div className="w-8 h-8 rounded-full bg-slate-600 border border-slate-400 flex items-center justify-center text-sm font-bold text-white relative">
                {user?.name.charAt(0).toUpperCase()}
                <div className="absolute bottom-0 right-0 w-2 h-2 bg-green-500 rounded-full border border-slate-600"></div>
                </div>
                <div className="overflow-hidden">
                <p className="text-sm font-medium truncate text-white hover:text-solutium-yellow transition-colors">{user?.name}</p>
                <p className="text-xs text-solutium-grey truncate">{user?.email}</p>
                </div>
            </div>

            <button 
                onClick={() => attemptNavigation('logout', 'logout')}
                className="w-full flex items-center space-x-2 px-2 py-2 text-sm text-red-300 hover:bg-white/5 rounded-lg transition-colors border-t border-white/5 pt-3"
            >
                <Icons.LogOut />
                <span>{t.signOut}</span>
            </button>
        </div>
      </aside>

      <main className="flex-1 h-screen overflow-y-auto p-4 md:p-8 bg-slate-50 relative">
        <div className="absolute top-0 right-0 w-64 h-64 bg-solutium-blue/5 rounded-full blur-3xl -z-10 transform translate-x-1/2 -translate-y-1/2"></div>
        {children}
      </main>

      {isMobileMenuOpen && (
        <div 
          className="fixed inset-0 bg-solutium-dark/80 z-10 md:hidden backdrop-blur-sm"
          onClick={() => setIsMobileMenuOpen(false)}
        />
      )}

      {/* CREATE PROJECT MODAL */}
      {showCreateModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-sm flex items-center justify-center p-4">
            <div className="bg-white rounded-xl shadow-2xl max-w-md w-full p-6 animate-scaleIn">
                <h3 className="text-xl font-bold text-slate-900 mb-4">{t.createProject}</h3>
                
                {user?.subscriptionPlan === 'free' && user.projects.length >= 3 && (
                    <div className="bg-amber-50 border border-amber-200 p-3 rounded-lg mb-4 flex items-start">
                        <span className="text-xl mr-2">⚠️</span>
                        <div className="text-sm text-amber-800">
                            <strong>{t.projectLimit}</strong><br/>
                            {t.upgradeForMore}
                        </div>
                    </div>
                )}

                <div className="space-y-4">
                    <Input 
                        label={t.labelProjectName}
                        value={newProjectName}
                        onChange={(e) => setNewProjectName(e.target.value)}
                        placeholder={t.phProjectName}
                    />
                    <div>
                        <label className="block text-sm font-medium text-slate-700 mb-1">
                              {t.labelCategory}
                        </label>
                        <select
                              value={newProjectIndustry}
                              onChange={(e) => setNewProjectIndustry(e.target.value)}
                              className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 bg-white"
                        >
                              <option value="" disabled>{t.wizSelectIndustry}</option>
                              {INDUSTRIES[currentLang].map((ind) => (
                                  <option key={ind} value={ind}>{ind}</option>
                              ))}
                        </select>
                    </div>
                    {(newProjectIndustry === 'Other' || newProjectIndustry === 'Otro') && (
                          <Input 
                            label={t.wizOtherIndustry}
                            value={customIndustry}
                            onChange={(e) => setCustomIndustry(e.target.value)}
                            placeholder={t.phIndustry}
                          />
                    )}
                </div>

                <div className="flex justify-end space-x-3 mt-8">
                    <button 
                        onClick={() => setShowCreateModal(false)}
                        className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-lg transition-colors"
                    >
                        {t.cancel}
                    </button>
                    <button 
                        onClick={handleCreateConfirm}
                        disabled={!newProjectName.trim() || !newProjectIndustry || (user?.subscriptionPlan === 'free' && user.projects.length >= 3)}
                        className="px-4 py-2 bg-solutium-blue text-white rounded-lg hover:bg-solutium-dark disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                        {t.create}
                    </button>
                </div>
            </div>
        </div>
      )}

      {/* UNSAVED CHANGES MODAL - REDESIGNED */}
      {showUnsavedModal && (
          <div className="fixed inset-0 z-[60] bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4">
              <div className="bg-white rounded-xl shadow-2xl max-w-sm w-full p-8 animate-scaleIn border-t-4 border-amber-400">
                  <div className="flex flex-col items-center text-center mb-6">
                      <div className="w-12 h-12 bg-amber-100 text-amber-500 rounded-full flex items-center justify-center mb-4">
                          <svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
                          </svg>
                      </div>
                      <h3 className="text-xl font-bold text-solutium-dark">
                          {t.unsavedTitle}
                      </h3>
                      <p className="text-slate-500 text-sm mt-2 leading-relaxed">
                          {t.unsavedChanges}
                      </p>
                  </div>
                  
                  <div className="flex flex-col space-y-3">
                      <Button 
                          variant="primary"
                          onClick={() => setShowUnsavedModal(false)}
                          className="w-full justify-center"
                          size="lg"
                      >
                          {t.keepEditing}
                      </Button>
                      <Button 
                          variant="ghost"
                          onClick={handleDiscardAndNavigate}
                          className="w-full justify-center text-red-500 hover:text-red-700 hover:bg-red-50"
                          size="md"
                      >
                          {t.discardChanges}
                      </Button>
                  </div>
              </div>
          </div>
      )}
    </div>
  );
};

export default Layout;