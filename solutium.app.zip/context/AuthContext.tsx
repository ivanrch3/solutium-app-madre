import React, { createContext, useContext, useState, useEffect } from 'react';
import { UserProfile, Language, Project, TeamMember } from '../types';
import { translations } from '../translations';

interface AuthContextType {
  user: UserProfile | null;
  currentProject: Project | null;
  login: (email: string, name: string) => void;
  guestLogin: () => void;
  logout: () => void;
  
  // Project Methods
  createProject: (name: string, industry?: string) => void;
  switchProject: (projectId: string) => void;
  updateProject: (projectId: string, data: Partial<Project>) => void;
  toggleProjectMember: (projectId: string, memberId: string) => void;
  
  // User/Team Methods
  updateProfile: (data: Partial<UserProfile>) => void;
  addTeamMember: (name: string, email: string, role: 'editor' | 'viewer') => boolean; // Returns success
  removeTeamMember: (memberId: string) => void;

  installApp: (appId: string) => void; // Installs to CURRENT project
  uninstallApp: (appId: string) => void; // Uninstalls from CURRENT project
  setLanguage: (lang: Language) => void;
  
  t: typeof translations['en']; 
  currentLang: Language;
  isLoading: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<UserProfile | null>(null);
  const [currentProject, setCurrentProject] = useState<Project | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [language, setLanguageState] = useState<Language>('es'); 

  useEffect(() => {
    const stored = localStorage.getItem('solutium_user');
    if (stored) {
      const parsedUser = JSON.parse(stored);
      setUser(parsedUser);
      if (parsedUser.language) setLanguageState(parsedUser.language);
      
      // Auto-select first project or last active project
      if (parsedUser.projects && parsedUser.projects.length > 0) {
          const lastProjectId = localStorage.getItem('solutium_last_project');
          const projectToLoad = parsedUser.projects.find((p: Project) => p.id === lastProjectId) || parsedUser.projects[0];
          setCurrentProject(projectToLoad);
      }
    }
    setIsLoading(false);
  }, []);

  const setLanguage = (lang: Language) => {
    setLanguageState(lang);
    if (user) {
      updateProfile({ language: lang });
    }
  };

  const login = (email: string, name: string) => {
    const role = email === 'admin@solutium.app' ? 'admin' : 'user';

    // Admin gets a default "HQ" project
    const defaultProjects: Project[] = role === 'admin' ? [{
        id: 'admin-hq',
        name: 'Solutium HQ',
        brandColors: ['#005e79', '#ffffff', '#000000'],
        socials: [],
        installedAppIds: ['web-builder', 'invoicer'],
        assignedMemberIds: [],
        createdAt: Date.now()
    }] : [];

    const newUser: UserProfile = {
      id: crypto.randomUUID(),
      name,
      email,
      role: role,
      language: language,
      subscriptionPlan: role === 'admin' ? 'enterprise' : 'free',
      projects: defaultProjects, 
      teamMembers: [],
      onboardingCompleted: role === 'admin', 
    };
    
    setUser(newUser);
    if (defaultProjects.length > 0) setCurrentProject(defaultProjects[0]);
    localStorage.setItem('solutium_user', JSON.stringify(newUser));
  };

  const guestLogin = () => {
    const guestUser: UserProfile = {
      id: 'guest',
      name: 'Invitado',
      email: '',
      role: 'guest',
      language: language,
      subscriptionPlan: 'free',
      projects: [],
      teamMembers: [],
      onboardingCompleted: false 
    };
    setUser(guestUser);
    localStorage.setItem('solutium_user', JSON.stringify(guestUser));
  };

  const logout = () => {
    setUser(null);
    setCurrentProject(null);
    localStorage.removeItem('solutium_user');
    localStorage.removeItem('solutium_last_project');
  };

  const createProject = (name: string, industry?: string) => {
      if (!user) return;
      
      const newProject: Project = {
          id: crypto.randomUUID(),
          name,
          industry,
          brandColors: ['#333333', '#ffffff', '#cccccc'],
          socials: [],
          installedAppIds: [],
          assignedMemberIds: [],
          createdAt: Date.now()
      };

      const updatedProjects = [...user.projects, newProject];
      updateProfile({ projects: updatedProjects });
      
      // Switch to new project
      setCurrentProject(newProject);
      localStorage.setItem('solutium_last_project', newProject.id);
  };

  const switchProject = (projectId: string) => {
      if (!user) return;
      const project = user.projects.find(p => p.id === projectId);
      if (project) {
          setCurrentProject(project);
          localStorage.setItem('solutium_last_project', project.id);
      }
  };

  const updateProject = (projectId: string, data: Partial<Project>) => {
      if (!user) return;
      
      const updatedProjects = user.projects.map(p => 
          p.id === projectId ? { ...p, ...data } : p
      );
      
      // Update User State
      const updatedUser = { ...user, projects: updatedProjects };
      setUser(updatedUser);
      localStorage.setItem('solutium_user', JSON.stringify(updatedUser));

      // Update Current Project State if it matches
      if (currentProject && currentProject.id === projectId) {
          setCurrentProject({ ...currentProject, ...data });
      }
  };

  const addTeamMember = (name: string, email: string, role: 'editor' | 'viewer') => {
      if (!user) return false;

      // Plan Limit Check
      const limit = user.subscriptionPlan === 'free' ? 0 : (user.subscriptionPlan === 'pro' ? 5 : 999);
      if (user.teamMembers.length >= limit) {
          return false;
      }

      const newMember: TeamMember = {
          id: crypto.randomUUID(),
          name,
          email,
          role,
          status: 'pending'
      };

      const updatedMembers = [...user.teamMembers, newMember];
      updateProfile({ teamMembers: updatedMembers });
      return true;
  };

  const removeTeamMember = (memberId: string) => {
      if (!user) return;
      const updatedMembers = user.teamMembers.filter(m => m.id !== memberId);
      updateProfile({ teamMembers: updatedMembers });
      // Also remove from all projects (complex logic omitted for brevity, but would go here)
  };

  const toggleProjectMember = (projectId: string, memberId: string) => {
      if (!user) return;
      const project = user.projects.find(p => p.id === projectId);
      if (!project) return;

      let newMemberIds = [...(project.assignedMemberIds || [])];
      if (newMemberIds.includes(memberId)) {
          newMemberIds = newMemberIds.filter(id => id !== memberId);
      } else {
          newMemberIds.push(memberId);
      }

      updateProject(projectId, { assignedMemberIds: newMemberIds });
  };

  const updateProfile = (data: Partial<UserProfile>) => {
    if (!user) return;
    const updated = { ...user, ...data };
    setUser(updated);
    localStorage.setItem('solutium_user', JSON.stringify(updated));
  };

  // Installs app into the CURRENT project
  const installApp = (appId: string) => {
    if (!user || !currentProject) return;

    // 1. Update the project object
    const updatedProject = {
        ...currentProject,
        installedAppIds: [...currentProject.installedAppIds, appId]
    };

    // 2. Update the user's project list
    const updatedProjects = user.projects.map(p => 
        p.id === currentProject.id ? updatedProject : p
    );

    // 3. Save both
    setCurrentProject(updatedProject);
    updateProfile({ projects: updatedProjects });
  };

  // Uninstalls app from the CURRENT project
  const uninstallApp = (appId: string) => {
    if (!user || !currentProject) return;

    // 1. Update the project object
    const updatedProject = {
        ...currentProject,
        installedAppIds: currentProject.installedAppIds.filter(id => id !== appId)
    };

    // 2. Update the user's project list
    const updatedProjects = user.projects.map(p => 
        p.id === currentProject.id ? updatedProject : p
    );

    // 3. Save both
    setCurrentProject(updatedProject);
    updateProfile({ projects: updatedProjects });
  };

  const t = translations[language];

  return (
    <AuthContext.Provider value={{ 
        user, 
        currentProject, 
        login, 
        guestLogin, 
        logout, 
        updateProfile, 
        createProject,
        switchProject,
        updateProject,
        toggleProjectMember,
        addTeamMember,
        removeTeamMember,
        installApp,
        uninstallApp,
        setLanguage, 
        t, 
        currentLang: language, 
        isLoading 
    }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};