import React from 'react';
import { useAuth } from '../context/AuthContext';
import { AVAILABLE_APPS } from '../constants';

const Portfolio: React.FC = () => {
  const { user, currentProject, installApp, t } = useAuth();
  
  const installedApps = AVAILABLE_APPS.filter(app => currentProject?.installedAppIds?.includes(app.id));
  const availableApps = AVAILABLE_APPS.filter(app => !currentProject?.installedAppIds?.includes(app.id));

  const handleInstall = (appId: string) => {
      // Small visual feedback logic could go here
      installApp(appId);
      // In a real app, maybe show a toast notification
  };

  return (
    <div className="max-w-6xl mx-auto space-y-8 pb-12 animate-fadeIn">
      <header>
        <h2 className="text-3xl font-bold text-solutium-dark">{t.portfolioTitle}</h2>
        <p className="text-solutium-grey mt-2">
            {t.portfolioDesc} <span className="font-bold text-solutium-blue">({currentProject?.name})</span>
        </p>
      </header>

      {/* Categories / Sections could be added here later */}

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {/* Available Apps */}
        {availableApps.map((app) => (
            <div key={app.id} className="bg-white rounded-xl border border-slate-200 p-6 flex flex-col hover:border-solutium-blue hover:shadow-lg transition-all">
              <div className="flex items-center space-x-4 mb-4">
                <div className="p-3 bg-slate-50 text-solutium-grey rounded-lg border border-slate-100 shadow-sm">
                  {app.icon}
                </div>
                <div>
                  <h4 className="font-bold text-lg text-solutium-dark">{app.name}</h4>
                  <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${
                    app.status === 'active' ? 'bg-blue-100 text-blue-700' : 'bg-amber-100 text-amber-700'
                  }`}>
                    {app.status.replace('_', ' ')}
                  </span>
                </div>
              </div>
              <p className="text-solutium-grey text-sm flex-1 mb-6 leading-relaxed">
                {app.description}
              </p>
              
              <button
                onClick={() => handleInstall(app.id)}
                disabled={app.status === 'coming_soon'}
                className="w-full py-2 px-4 border border-solutium-blue text-solutium-blue rounded-lg font-medium hover:bg-solutium-blue hover:text-white transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {t.install}
              </button>
            </div>
        ))}

        {/* Installed Apps (Visual confirmation they exist) */}
        {installedApps.map((app) => (
            <div key={app.id} className="bg-slate-50 rounded-xl border border-slate-200 p-6 flex flex-col opacity-60">
              <div className="flex items-center space-x-4 mb-4">
                <div className="p-3 bg-white text-solutium-grey rounded-lg">
                  {app.icon}
                </div>
                <div>
                  <h4 className="font-bold text-lg text-slate-500">{app.name}</h4>
                  <span className="text-xs bg-green-100 text-green-700 px-2 py-0.5 rounded-full font-medium">{t.installed}</span>
                </div>
              </div>
              <p className="text-slate-400 text-sm flex-1 mb-6">
                {app.description}
              </p>
              <button disabled className="w-full py-2 px-4 bg-slate-200 text-slate-500 rounded-lg font-medium cursor-default">
                {t.installed}
              </button>
            </div>
        ))}
      </div>
    </div>
  );
};

export default Portfolio;