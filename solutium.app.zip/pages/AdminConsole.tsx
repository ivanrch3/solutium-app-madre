import React, { useState, useEffect, useRef } from 'react';
import { useAuth } from '../context/AuthContext';
import { AVAILABLE_APPS, DOMAINS } from '../constants';
import { Input } from '../components/Input';
import { Button } from '../components/Button';

// Types for the Diagnostic System
interface DiagnosticLog {
    id: number;
    timestamp: string;
    source: string;
    message: string;
    status: 'info' | 'success' | 'error' | 'warning';
}

interface AppHealth {
    id: string;
    status: 'online' | 'offline' | 'checking' | 'unknown';
    latency: number | null;
    lastCheck: string | null;
    errorDetail?: string;
}

const AdminConsole: React.FC = () => {
  const { user, t } = useAuth();
  const [emailApiKey, setEmailApiKey] = useState('');
  const [audienceId, setAudienceId] = useState('');
  const [activeUsers, setActiveUsers] = useState(124);

  // DIAGNOSTIC STATE
  const [diagnosingId, setDiagnosingId] = useState<string | null>(null); // Only one running at a time
  const [logs, setLogs] = useState<DiagnosticLog[]>([]);
  const [appHealth, setAppHealth] = useState<Record<string, AppHealth>>({});
  const logsEndRef = useRef<HTMLDivElement>(null);

  // Load existing configuration
  useEffect(() => {
    const storedKey = localStorage.getItem('solutium_emailit_key');
    const storedAudience = localStorage.getItem('solutium_emailit_audience');
    
    if (storedKey) setEmailApiKey(storedKey);
    if (storedAudience) setAudienceId(storedAudience);

    // Initialize App Health State
    const initialHealth: Record<string, AppHealth> = {};
    AVAILABLE_APPS.forEach(app => {
        initialHealth[app.id] = { id: app.id, status: 'unknown', latency: null, lastCheck: null };
    });
    setAppHealth(initialHealth);

    // Simulate real-time user fluctuation
    const interval = setInterval(() => {
        setActiveUsers(prev => {
            const change = Math.floor(Math.random() * 5) - 2; 
            return Math.max(100, prev + change);
        });
    }, 3000);

    return () => clearInterval(interval);
  }, []);

  // Auto-scroll logs
  useEffect(() => {
      logsEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [logs]);

  const addLog = (message: string, status: DiagnosticLog['status'] = 'info', source: string = 'SYSTEM') => {
      const newLog: DiagnosticLog = {
          id: Date.now(),
          timestamp: new Date().toLocaleTimeString(),
          source,
          message,
          status
      };
      setLogs(prev => [...prev, newLog]);
  };

  const handleSaveEmailConfig = () => {
      localStorage.setItem('solutium_emailit_key', emailApiKey);
      localStorage.setItem('solutium_emailit_audience', audienceId);
      addLog("Configuration saved to local secure storage.", 'success', 'CONFIG');
      alert(t.saved);
  };

  // --- CORE DIAGNOSTIC ENGINE ---
  const runDiagnostics = async (targetAppId?: string) => {
      if (diagnosingId) return; // Prevent concurrent runs

      const appsToScan = targetAppId 
        ? AVAILABLE_APPS.filter(a => a.id === targetAppId)
        : AVAILABLE_APPS;

      setDiagnosingId(targetAppId || 'ALL');
      
      if (!targetAppId) {
        setLogs([]); // Clear logs only on full scan
        addLog("Initializing Full Network Topology Scan...", 'info');
      } else {
        addLog(`Initializing Single Target Scan: ${targetAppId.toUpperCase()}...`, 'info');
      }

      addLog(`Environment: ${window.location.hostname}`, 'info');

      const updatedHealth = { ...appHealth };

      // Iterate Selected Apps
      for (const app of appsToScan) {
          addLog(`Pinging Node: ${app.name.toUpperCase()} (${app.url})...`, 'info', app.id);
          
          // Update status to checking
          updatedHealth[app.id] = { ...updatedHealth[app.id], status: 'checking' };
          setAppHealth({ ...updatedHealth });

          const startTime = performance.now();
          
          try {
              // We use mode: 'no-cors' to allow the browser to send the request even if the 
              // local dev server doesn't return CORS headers. 
              // If the server is DOWN, this will throw a Network Error.
              // If the server is UP, it will return an opaque response (success).
              await fetch(app.url, { mode: 'no-cors', cache: 'no-store' });
              
              const latency = Math.round(performance.now() - startTime);
              
              addLog(`Connection established. Latency: ${latency}ms`, 'success', app.id);
              updatedHealth[app.id] = { 
                  id: app.id, 
                  status: 'online', 
                  latency, 
                  lastCheck: new Date().toLocaleTimeString(),
                  errorDetail: undefined
              };

          } catch (error: any) {
              console.error(error);
              const errorMsg = error.message || 'Unknown Error';
              addLog(`CONNECTION REFUSED. ${errorMsg}`, 'error', app.id);
              
              // Specific hint for Localhost
              if (app.url.includes('localhost')) {
                   const port = app.url.split(':').pop();
                   addLog(`Audit Hint: Is the terminal for port ${port} running?`, 'warning', 'AUDIT');
              }
              
              updatedHealth[app.id] = { 
                  id: app.id, 
                  status: 'offline', 
                  latency: null, 
                  lastCheck: new Date().toLocaleTimeString(),
                  errorDetail: errorMsg
              };
          }
          
          // Update state after each check
          setAppHealth({ ...updatedHealth });
          await new Promise(r => setTimeout(r, 300)); // Pace the checks
      }

      if (!targetAppId) {
          addLog("Full diagnostic sequence completed.", 'info', 'SYSTEM');
      }
      setDiagnosingId(null);
  };

  const handleDownloadReport = () => {
      const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
      const header = `SOLUTIUM NETWORK DIAGNOSTIC REPORT\nGenerated: ${new Date().toLocaleString()}\nEnvironment: ${window.location.href}\nUser Agent: ${navigator.userAgent}\n----------------------------------------\n\n`;
      
      let healthSection = "APP HEALTH STATUS:\n";
      Object.values(appHealth).forEach(h => {
          healthSection += `[${h.status.toUpperCase()}] ${h.id} | Latency: ${h.latency ? h.latency + 'ms' : 'N/A'} | Last Check: ${h.lastCheck || 'Never'}\n`;
          if (h.errorDetail) healthSection += `   Error: ${h.errorDetail}\n`;
      });

      let logSection = "\nEXECUTION LOGS:\n";
      logs.forEach(l => {
          logSection += `[${l.timestamp}] [${l.source}] ${l.status.toUpperCase()}: ${l.message}\n`;
      });

      const fullReport = header + healthSection + logSection;
      
      const blob = new Blob([fullReport], { type: 'text/plain' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `solutium_report_${timestamp}.txt`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
  };

  if (user?.role !== 'admin') {
    return <div className="text-red-600">Access Denied. Admin privileges required.</div>;
  }

  // Detect environment for display
  const isLocal = typeof window !== 'undefined' && (
    window.location.hostname === 'localhost' || 
    window.location.hostname === '127.0.0.1' ||
    window.location.port !== ''
  );

  return (
    <div className="space-y-8 animate-fadeIn pb-12">
      <header className="border-b border-slate-200 pb-6">
        <h2 className="text-3xl font-bold text-solutium-dark flex items-center">
           <span className="w-3 h-3 bg-red-500 rounded-full mr-3 animate-pulse"></span>
           {t.adminTitle}
        </h2>
        <p className="text-solutium-grey mt-2">{t.adminDesc}</p>
      </header>

      {/* Real-time Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="bg-solutium-dark text-white p-6 rounded-xl shadow-lg relative overflow-hidden">
              <div className="absolute top-0 right-0 w-32 h-32 bg-solutium-blue rounded-full opacity-20 transform translate-x-10 -translate-y-10"></div>
              <h3 className="text-sm font-medium text-solutium-yellow uppercase tracking-wider mb-2">{t.totalUsers}</h3>
              <p className="text-4xl font-bold">1,204</p>
              <p className="text-xs text-slate-400 mt-2">+12% this week</p>
          </div>
          <div className="bg-white text-solutium-dark p-6 rounded-xl shadow-lg border-l-4 border-green-500">
              <h3 className="text-sm font-bold text-solutium-grey uppercase tracking-wider mb-2 flex items-center">
                  <span className="w-2 h-2 bg-green-500 rounded-full mr-2 animate-pulse"></span>
                  {t.activeUsersNow}
              </h3>
              <p className="text-4xl font-bold">{activeUsers}</p>
              <p className="text-xs text-slate-500 mt-2">Live metric</p>
          </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        
        {/* NETWORK TOPOLOGY & DIAGNOSTICS */}
        <div className="space-y-6">
            <div className="bg-white p-6 rounded-xl shadow-lg border-t-4 border-slate-700">
                <div className="flex justify-between items-center mb-6">
                    <h3 className="text-xl font-bold text-solutium-dark flex items-center">
                        Network Topology
                        {isLocal && <span className="ml-2 px-2 py-0.5 bg-yellow-100 text-yellow-800 text-xs rounded-full font-bold">LOCALHOST</span>}
                    </h3>
                    <Button 
                        size="sm" 
                        variant="secondary"
                        onClick={() => runDiagnostics()}
                        isLoading={diagnosingId === 'ALL'}
                        disabled={!!diagnosingId}
                    >
                        Check All
                    </Button>
                </div>
                
                <div className="space-y-4">
                    {AVAILABLE_APPS.map(app => {
                        const health = appHealth[app.id] || { status: 'unknown' };
                        const isOnline = health.status === 'online';
                        const isOffline = health.status === 'offline';
                        const isChecking = health.status === 'checking';
                        const isScanningThis = diagnosingId === app.id;

                        return (
                            <div key={app.id} className="flex justify-between items-center p-3 bg-slate-50 rounded border border-slate-200 transition-all">
                                <div className="flex items-center space-x-3 flex-1 overflow-hidden">
                                    {/* Status Dot */}
                                    <div className={`w-3 h-3 rounded-full shrink-0 ${
                                        isOnline ? 'bg-green-500 shadow-green-200 shadow-[0_0_8px]' : 
                                        isOffline ? 'bg-red-500' : 
                                        isChecking ? 'bg-yellow-400 animate-pulse' : 'bg-slate-300'
                                    }`}></div>
                                    
                                    <div className="min-w-0">
                                        <div className="font-bold text-slate-700 text-sm truncate">{app.name.toUpperCase()}</div>
                                        <div className="font-mono text-xs text-slate-400 truncate">{app.url}</div>
                                    </div>
                                </div>
                                
                                <div className="flex items-center space-x-4">
                                    <div className="text-right hidden sm:block">
                                        {isOnline && <span className="text-xs font-mono text-green-600 font-bold">{health.latency}ms</span>}
                                        {isOffline && <span className="text-xs font-mono text-red-500 font-bold">OFFLINE</span>}
                                        {health.status === 'unknown' && <span className="text-xs text-slate-400">---</span>}
                                    </div>

                                    {/* INDIVIDUAL TEST BUTTON */}
                                    <button 
                                        onClick={() => runDiagnostics(app.id)}
                                        disabled={!!diagnosingId}
                                        className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center shadow-sm ${
                                            isScanningThis 
                                                ? 'bg-slate-200 text-slate-500 cursor-wait' 
                                                : 'bg-white border border-slate-300 hover:bg-solutium-blue hover:text-white hover:border-solutium-blue'
                                        }`}
                                    >
                                        {isScanningThis ? (
                                            <span className="animate-pulse">Testing...</span>
                                        ) : (
                                            <>
                                                <svg className="w-3 h-3 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14.752 11.168l-3.197-2.132A1 1 0 0010 9.87v4.263a1 1 0 001.555.832l3.197-2.132a1 1 0 000-1.664z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
                                                Test
                                            </>
                                        )}
                                    </button>
                                </div>
                            </div>
                        );
                    })}
                </div>
            </div>

            {/* LIVE CONSOLE LOG */}
            <div className="bg-slate-900 rounded-xl shadow-lg overflow-hidden flex flex-col h-64 border border-slate-700">
                <div className="bg-slate-800 px-4 py-2 flex justify-between items-center border-b border-slate-700">
                    <span className="text-xs font-mono text-slate-400">TERMINAL OUTPUT</span>
                    
                    {/* DOWNLOAD REPORT BUTTON */}
                    <button 
                        onClick={handleDownloadReport}
                        className="flex items-center space-x-1 text-xs text-solutium-blue font-bold hover:text-white transition-colors"
                        title="Download diagnostic logs for support"
                    >
                        <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" /></svg>
                        <span>Download Report</span>
                    </button>
                </div>
                <div className="flex-1 p-4 overflow-y-auto font-mono text-xs space-y-1">
                    {logs.length === 0 && (
                        <div className="text-slate-500 italic opacity-50">System ready. Select a node to test...</div>
                    )}
                    {logs.map((log) => (
                        <div key={log.id} className="flex space-x-2">
                            <span className="text-slate-500">[{log.timestamp}]</span>
                            <span className={`font-bold w-16 text-right ${
                                log.source === 'SYSTEM' ? 'text-blue-400' : 
                                log.source === 'AUDIT' ? 'text-yellow-400' : 'text-purple-400'
                            }`}>
                                {log.source}:
                            </span>
                            <span className={`${
                                log.status === 'error' ? 'text-red-400 font-bold' : 
                                log.status === 'success' ? 'text-green-400' : 
                                log.status === 'warning' ? 'text-yellow-300' : 'text-slate-300'
                            }`}>
                                {log.message}
                            </span>
                        </div>
                    ))}
                    <div ref={logsEndRef} />
                </div>
            </div>
        </div>

        {/* Global Configs (Existing) */}
        <div className="space-y-8">
            <div className="bg-white p-6 rounded-xl shadow-lg border-t-4 border-red-500">
                <h3 className="text-xl font-bold text-solutium-dark mb-4">{t.masterSettings}</h3>
                
                <div className="space-y-4">
                    <div className="flex justify-between items-center p-3 bg-slate-50 rounded">
                        <div>
                            <p className="font-medium">{t.systemStatus}</p>
                            <p className="text-xs text-green-600">{t.allSystemsOp}</p>
                        </div>
                        <button className="text-sm bg-white border border-slate-300 px-3 py-1 rounded">Force Check</button>
                    </div>

                    <div className="flex justify-between items-center p-3 bg-slate-50 rounded">
                        <div>
                            <p className="font-medium">{t.globalTheme}</p>
                            <p className="text-xs text-solutium-grey">{t.lockedTheme}</p>
                        </div>
                        <button className="text-sm bg-solutium-blue text-white px-3 py-1 rounded">{t.editPalette}</button>
                    </div>
                </div>
            </div>

             {/* Application Registry (Read Only) */}
            <div className="bg-white p-6 rounded-xl shadow-lg border-t-4 border-solutium-blue">
                <h3 className="text-xl font-bold text-solutium-dark mb-4">{t.appRegistry}</h3>
                
                <table className="w-full text-sm text-left">
                    <thead className="bg-slate-100 text-solutium-dark">
                        <tr>
                            <th className="p-2 rounded-l">ID</th>
                            <th className="p-2">Name</th>
                            <th className="p-2 rounded-r">{t.status}</th>
                        </tr>
                    </thead>
                    <tbody>
                        {AVAILABLE_APPS.map(app => (
                            <tr key={app.id} className="border-b border-slate-100">
                                <td className="p-2 font-mono text-xs">{app.id}</td>
                                <td className="p-2 font-bold">{app.name}</td>
                                <td className="p-2">
                                    <span className={`px-2 py-1 rounded-full text-xs ${app.status === 'active' ? 'bg-green-100 text-green-800' : 'bg-amber-100 text-amber-800'}`}>
                                        {app.status}
                                    </span>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </div>

      </div>

    </div>
  );
};

export default AdminConsole;