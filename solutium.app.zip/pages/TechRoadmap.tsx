import React from 'react';
import { useAuth } from '../context/AuthContext';

const TechRoadmap: React.FC = () => {
  const { t } = useAuth();
  
  return (
    <div className="max-w-5xl mx-auto space-y-8 pb-12">
      <header>
        <h2 className="text-3xl font-bold text-slate-900">{t.roadmapTitle}</h2>
        <p className="text-slate-600 mt-2">{t.roadmapDesc}</p>
      </header>

      {/* Strategic Questions */}
      <section className="bg-white rounded-xl shadow-sm border border-slate-200 p-8">
        <h3 className="text-xl font-bold text-indigo-700 mb-6 flex items-center">
          <span className="w-8 h-8 rounded-full bg-indigo-100 flex items-center justify-center mr-3 text-sm">1</span>
          {t.stratQuestions}
        </h3>
        <div className="grid gap-6">
          <div className="space-y-2">
            <h4 className="font-bold text-slate-900">{t.authArch}</h4>
            <p className="text-slate-600 text-sm">
              <strong>Question:</strong> How to handle the Marketplace logic securely?
            </p>
            <p className="text-slate-500 text-sm italic">
              <strong>Decision:</strong> We use an <code>installedAppIds</code> array in the User Profile. Satellite apps must verify this ID exists in the user's token before loading. This prevents users from accessing apps they haven't "added" or paid for.
            </p>
          </div>
          
          <div className="space-y-2">
            <h4 className="font-bold text-slate-900">External Integrations (Email It)</h4>
            <p className="text-slate-600 text-sm">
              <strong>Question:</strong> How to prevent registration failure if Email It is down?
            </p>
            <p className="text-slate-500 text-sm italic">
              <strong>Decision:</strong> Use <strong>Asynchronous Webhooks</strong>. When a user registers, we save them to our DB immediately. Then, we fire a background event to sync with Email It. If Email It fails, we retry later without disrupting the user.
            </p>
          </div>
        </div>
      </section>

      {/* PRIORITIZED ROADMAP */}
      <section className="bg-white rounded-xl shadow-sm border border-slate-200 p-8">
         <h3 className="text-xl font-bold text-slate-900 mb-6">Prioritized Execution Plan</h3>
         <div className="relative border-l-2 border-slate-200 ml-3 space-y-12">
            
            {/* PRIORITY 1: INTEGRATIONS */}
            <div className="relative pl-8">
              <div className="absolute -left-[9px] top-0 w-4 h-4 rounded-full bg-green-500 border-2 border-white shadow-sm"></div>
              <h4 className="font-bold text-slate-900 flex items-center">
                PRIORITY 1: Connectivity & Marketing Engine
                <span className="ml-2 text-xs bg-green-100 text-green-800 px-2 py-0.5 rounded-full">Completed v1.0</span>
              </h4>
              <p className="text-slate-600 text-sm mt-2">
                <strong>Objective:</strong> Connect "Email It" to automate user engagement.
              </p>
              <ul className="mt-2 space-y-1 text-sm text-slate-500 list-disc list-inside">
                <li className="line-through text-slate-400">Define API Client for Email It.</li>
                <li className="line-through text-slate-400">Create "Webhooks Settings" page in Admin Console.</li>
                <li className="line-through text-slate-400">Implement "Welcome Email" trigger on Registration.</li>
              </ul>
            </div>

            {/* PRIORITY 2: PROFESSIONALIZATION (UX) */}
            <div className="relative pl-8">
              <div className="absolute -left-[9px] top-0 w-4 h-4 rounded-full bg-green-500 border-2 border-white shadow-sm"></div>
              <h4 className="font-bold text-slate-900 flex items-center">
                  PRIORITY 2: Professional UX & Onboarding
                  <span className="ml-2 text-xs bg-green-100 text-green-800 px-2 py-0.5 rounded-full">Completed v1.1</span>
              </h4>
              <p className="text-slate-600 text-sm mt-2">
                <strong>Objective:</strong> Increase perceived quality and user retention.
              </p>
              <ul className="mt-2 space-y-1 text-sm text-slate-500 list-disc list-inside">
                <li className="line-through text-slate-400">Guided Onboarding (Wizard)</li>
                <li className="line-through text-slate-400">Skeleton Loaders & Animations</li>
                <li className="line-through text-slate-400">Premium Empty States</li>
              </ul>
            </div>

            {/* PRIORITY 3: SECURITY & MONITORING */}
            <div className="relative pl-8">
              <div className="absolute -left-[9px] top-0 w-4 h-4 rounded-full bg-amber-500 border-2 border-white shadow-sm"></div>
              <h4 className="font-bold text-slate-900 flex items-center">
                  PRIORITY 3: Security & Stability
                  <span className="ml-2 text-xs bg-amber-100 text-amber-800 px-2 py-0.5 rounded-full">Next Up</span>
              </h4>
              <p className="text-slate-600 text-sm mt-2">
                <strong>Objective:</strong> Protect data and ensure uptime transparency.
              </p>
              <ul className="mt-2 space-y-1 text-sm text-slate-500 list-disc list-inside">
                <li><strong>Audit Logs:</strong> Track who changed what in the Admin Console.</li>
                <li><strong>Status Page:</strong> Public facing page showing system uptime.</li>
                <li><strong>MFA:</strong> Multi-factor authentication for Admin accounts.</li>
              </ul>
            </div>

             {/* PRIORITY 4: SATELLITE APPS */}
             <div className="relative pl-8">
              <div className="absolute -left-[9px] top-0 w-4 h-4 rounded-full bg-slate-300 border-2 border-white"></div>
              <h4 className="font-bold text-slate-900">PRIORITY 4: The Spokes (Satellite Apps)</h4>
              <p className="text-slate-600 text-sm mt-2">
                <strong>Objective:</strong> Build the actual tools.
              </p>
              <ul className="mt-2 space-y-1 text-sm text-slate-500 list-disc list-inside">
                <li>Develop <strong>ProForma (Invoicer)</strong>. It will be the testing ground for the "Installed App" logic.</li>
                <li>Develop <strong>SiteCrafter (Web Builder)</strong>.</li>
              </ul>
            </div>

         </div>
      </section>

      {/* Integration Guide (Reference) */}
      <section className="bg-slate-900 text-slate-100 rounded-xl shadow-lg p-8 opacity-80">
        <h3 className="text-xl font-bold text-white mb-6">{t.integrationProto}</h3>
        <p className="text-slate-300 text-sm">
           Refer to <code>MASTER_MEMORY.md</code> for the full technical specification on Token Injection and Profile Fetching.
        </p>
      </section>
    </div>
  );
};

export default TechRoadmap;