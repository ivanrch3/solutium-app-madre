import React, { useEffect, useState } from 'react';
import { connectToSolutium, type SolutiumPayload } from '../utils/satelliteConnection';

/**
 * ---------------------------------------------------------------------
 * PLANTILLA MAESTRA PARA APLICACIÓN SATÉLITE (App.tsx)
 * ---------------------------------------------------------------------
 * INSTRUCCIONES:
 * 1. Copia todo este código.
 * 2. Pégalo en el archivo 'src/App.tsx' de tu SEGUNDO proyecto (el que corre en puerto 3001).
 * 3. Asegúrate de tener 'utils/satelliteConnection.ts' en tu segundo proyecto también.
 * ---------------------------------------------------------------------
 */

interface InvoicerAppProps {
  onExit?: () => void;
}

const App: React.FC<InvoicerAppProps> = ({ onExit }) => {
  const [config, setConfig] = useState<SolutiumPayload['projectData'] | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  // Datos específicos de esta App (Ej: Cotizador)
  const [items, setItems] = useState([{ desc: 'Servicio Ejemplo', price: 100 }]);

  useEffect(() => {
    // 1. EL HANDSHAKE (CONEXIÓN)
    // Al iniciar, buscamos el token en la URL o en la memoria de sesión
    const payload = connectToSolutium();
    
    if (payload && payload.projectData) {
        console.log("🛰️ Conexión Satelital Exitosa:", payload);
        setConfig(payload.projectData);
        setLoading(false);
    } else {
        // Si falla la conexión, mostramos error o redirigimos
        console.warn("⚠️ No se detectó sesión de Solutium.");
        setError('Acceso denegado. Por favor abre esta aplicación desde tu panel de Solutium.');
        setLoading(false);
    }
  }, []);

  if (loading) {
      return (
        <div className="min-h-screen flex items-center justify-center bg-gray-50">
           <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
           <span className="ml-3 text-gray-500">Conectando con Solutium...</span>
        </div>
      );
  }

  if (error) {
      return (
          <div className="min-h-screen flex flex-col items-center justify-center bg-gray-100 p-8 text-center">
              <div className="bg-white p-8 rounded-xl shadow-lg max-w-md">
                <div className="w-16 h-16 bg-red-100 text-red-500 rounded-full flex items-center justify-center mx-auto mb-4">
                    <svg className="w-8 h-8" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" /></svg>
                </div>
                <h1 className="text-2xl font-bold text-gray-800 mb-2">Error de Conexión</h1>
                <p className="text-gray-600 mb-6">{error}</p>
                <button 
                    onClick={() => onExit ? onExit() : window.location.href = 'http://localhost:3000'}
                    className="block w-full py-3 bg-gray-800 text-white rounded-lg font-bold hover:bg-black transition-colors"
                >
                    Ir al Dashboard Principal
                </button>
              </div>
          </div>
      );
  }

  if (!config) return null;

  // --- INTERFAZ DE LA APLICACIÓN SATÉLITE ---
  // A partir de aquí, la app usa los colores y datos recibidos de la Madre.
  
  const primaryColor = config.colors?.[0] || '#2563EB'; // Color principal de la marca
  const secondaryColor = config.colors?.[1] || '#FFFFFF'; 

  return (
    <div className="min-h-screen bg-gray-50 font-sans text-gray-800">
      
      {/* HEADER: Personalizado con la marca del usuario */}
      <header className="shadow-sm transition-colors duration-500" style={{ backgroundColor: primaryColor }}>
          <div className="max-w-5xl mx-auto px-6 py-4 flex justify-between items-center">
              <div className="flex items-center space-x-4">
                  {config.logoUrl ? (
                      <img src={config.logoUrl} alt="Logo" className="h-10 w-auto bg-white/20 p-1 rounded" />
                  ) : (
                      <span className="text-white font-bold text-xl">{config.name}</span>
                  )}
              </div>
              <div className="text-white/80 text-sm">
                  Generador de Cotizaciones
              </div>
          </div>
      </header>

      <main className="max-w-5xl mx-auto p-8">
          
          <div className="bg-white rounded-xl shadow-xl overflow-hidden border border-gray-200">
              {/* DOCUMENT PREVIEW */}
              <div className="p-12">
                  <div className="flex justify-between items-start mb-12">
                      <div>
                          <h2 className="text-3xl font-bold text-gray-900 mb-1">Cotización</h2>
                          <p className="text-gray-500">#COT-2024-001</p>
                      </div>
                      <div className="text-right">
                          <h3 className="font-bold text-lg">{config.name}</h3>
                          <p className="text-gray-500 text-sm">{config.contact.address}</p>
                          <p className="text-gray-500 text-sm">{config.contact.email}</p>
                          <p className="text-gray-500 text-sm">{config.contact.phone}</p>
                      </div>
                  </div>

                  <table className="w-full mb-8">
                      <thead>
                          <tr className="border-b-2 border-gray-100">
                              <th className="text-left py-3 text-sm font-bold text-gray-500 uppercase">Descripción</th>
                              <th className="text-right py-3 text-sm font-bold text-gray-500 uppercase">Total</th>
                          </tr>
                      </thead>
                      <tbody>
                          {items.map((item, idx) => (
                              <tr key={idx} className="border-b border-gray-50">
                                  <td className="py-4 text-gray-700">{item.desc}</td>
                                  <td className="py-4 text-right font-mono font-medium">${item.price.toFixed(2)}</td>
                              </tr>
                          ))}
                      </tbody>
                  </table>
                  
                  <div className="flex justify-end mt-8">
                      <div className="bg-gray-50 p-6 rounded-lg w-1/3">
                          <div className="flex justify-between mb-2 text-sm">
                              <span className="text-gray-600">Subtotal:</span>
                              <span className="font-bold">$100.00</span>
                          </div>
                          <div className="flex justify-between text-xl font-bold border-t border-gray-200 pt-4 mt-2" style={{ color: primaryColor }}>
                              <span>Total:</span>
                              <span>$100.00</span>
                          </div>
                      </div>
                  </div>
              </div>

              {/* ACTION BAR */}
              <div className="bg-gray-50 p-6 border-t border-gray-200 flex justify-between items-center">
                  <button onClick={() => alert("Funcionalidad de guardar...")} className="text-gray-500 hover:text-gray-700 font-medium">
                      Guardar Borrador
                  </button>
                  <button 
                    className="px-8 py-3 text-white font-bold rounded shadow-lg transform hover:-translate-y-0.5 transition-all"
                    style={{ backgroundColor: primaryColor }}
                  >
                      Enviar Cotización
                  </button>
              </div>
          </div>
      </main>

      {/* Floating Exit Button for Simulation Mode */}
      {onExit && (
          <button 
            onClick={onExit}
            className="fixed bottom-4 right-4 bg-gray-800 text-white px-4 py-2 rounded-full shadow-lg hover:bg-black transition-colors z-50 text-sm font-medium"
          >
            ← Volver al Panel
          </button>
      )}
    </div>
  );
};

export default App;