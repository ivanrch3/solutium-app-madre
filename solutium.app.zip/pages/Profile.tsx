import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { Input } from '../components/Input';
import { TeamMember } from '../types';

const Profile: React.FC = () => {
  const { user, updateProfile, addTeamMember, removeTeamMember, t, setLanguage, currentLang } = useAuth();
  const [activeTab, setActiveTab] = useState<'account' | 'team'>('account');
  
  // Account Form State
  const [formData, setFormData] = useState({
    name: user?.name || '',
    email: user?.email || '',
    phone: user?.phone || '',
    password: '',
    newPassword: ''
  });

  // Team Form State
  const [newMemberName, setNewMemberName] = useState('');
  const [newMemberEmail, setNewMemberEmail] = useState('');
  const [isSaved, setIsSaved] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  const handleAccountChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData(prev => ({ ...prev, [e.target.name]: e.target.value }));
    setIsSaved(false);
  };

  const handleAccountSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    updateProfile({ name: formData.name, phone: formData.phone });
    // Password change logic would be API call here
    setIsSaved(true);
    setTimeout(() => setIsSaved(false), 3000);
  };

  const handleAddMember = (e: React.FormEvent) => {
      e.preventDefault();
      setErrorMsg('');
      if (!newMemberName || !newMemberEmail) return;

      const success = addTeamMember(newMemberName, newMemberEmail, 'editor');
      if (success) {
          setNewMemberName('');
          setNewMemberEmail('');
      } else {
          setErrorMsg(t.limitReached);
      }
  };

  return (
    <div className="max-w-5xl mx-auto pb-12">
      <header className="mb-8">
          <h2 className="text-3xl font-bold text-solutium-dark">{t.profile}</h2>
          <p className="text-solutium-grey mt-1">{t.accountOverview}</p>
      </header>

      {/* Stats Cards (Moved from Dashboard) */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <div className="bg-white p-6 rounded-xl shadow-sm border-l-4 border-solutium-blue">
          <h3 className="text-xs font-bold text-solutium-grey uppercase tracking-wider mb-2">{t.subscription}</h3>
          <p className="text-2xl font-bold text-solutium-blue capitalize">{user?.subscriptionPlan}</p>
          <button className="text-xs text-solutium-blue underline mt-2">{t.upgrade}</button>
        </div>
        <div className="bg-white p-6 rounded-xl shadow-sm border-l-4 border-indigo-500">
           <h3 className="text-xs font-bold text-solutium-grey uppercase tracking-wider mb-2">Projects</h3>
           <p className="text-2xl font-bold text-solutium-dark">{user?.projects.length}</p>
        </div>
        <div className="bg-white p-6 rounded-xl shadow-sm border-l-4 border-green-500">
           <h3 className="text-xs font-bold text-solutium-grey uppercase tracking-wider mb-2">Team Members</h3>
           <p className="text-2xl font-bold text-solutium-dark">{user?.teamMembers.length}</p>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex space-x-1 bg-slate-200 p-1 rounded-lg mb-6 w-fit">
          <button 
            onClick={() => setActiveTab('account')}
            className={`px-4 py-2 rounded-md text-sm font-medium transition-all ${activeTab === 'account' ? 'bg-white shadow text-solutium-blue' : 'text-slate-500 hover:text-slate-700'}`}
          >
              {t.personalInfo}
          </button>
          <button 
            onClick={() => setActiveTab('team')}
            className={`px-4 py-2 rounded-md text-sm font-medium transition-all ${activeTab === 'team' ? 'bg-white shadow text-solutium-blue' : 'text-slate-500 hover:text-slate-700'}`}
          >
              {t.teamManagement}
          </button>
      </div>

      {/* ACCOUNT TAB */}
      {activeTab === 'account' && (
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
            <form onSubmit={handleAccountSubmit} className="p-6 md:p-8 space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <Input 
                label={t.labelName} 
                name="name" 
                value={formData.name} 
                onChange={handleAccountChange} 
                />
                <Input 
                label={t.labelPhone} 
                name="phone" 
                value={formData.phone} 
                onChange={handleAccountChange} 
                placeholder="+1 (555) 000-0000"
                />
                <Input 
                label={t.labelEmail} 
                name="email" 
                type="email"
                value={formData.email} 
                readOnly 
                className="bg-slate-100 cursor-not-allowed"
                />
                 {/* Language Selector */}
                 <div className="mb-4">
                    <label className="block text-sm font-medium text-slate-700 mb-1">
                        {t.lang}
                    </label>
                    <div className="flex bg-slate-100 p-1 rounded-lg w-fit">
                        <button 
                            type="button"
                            onClick={() => setLanguage('es')}
                            className={`px-4 py-2 rounded-md text-sm font-medium transition-all ${currentLang === 'es' ? 'bg-white shadow text-solutium-blue' : 'text-slate-500 hover:text-slate-700'}`}
                        >
                            Español
                        </button>
                        <button 
                            type="button"
                            onClick={() => setLanguage('en')}
                            className={`px-4 py-2 rounded-md text-sm font-medium transition-all ${currentLang === 'en' ? 'bg-white shadow text-solutium-blue' : 'text-slate-500 hover:text-slate-700'}`}
                        >
                            English
                        </button>
                    </div>
                </div>
            </div>

            <div className="pt-6 border-t border-slate-100">
                <h3 className="text-lg font-bold text-slate-800 mb-4">{t.security}</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <Input 
                        label={t.currentPassword} 
                        name="password" 
                        type="password"
                        placeholder="••••••"
                        value={formData.password}
                        onChange={handleAccountChange}
                    />
                    <Input 
                        label={t.newPassword} 
                        name="newPassword" 
                        type="password"
                        placeholder="••••••"
                        value={formData.newPassword}
                        onChange={handleAccountChange}
                    />
                </div>
            </div>

            <div className="flex items-center justify-between pt-4">
                <span className={`text-sm text-green-600 font-medium transition-opacity ${isSaved ? 'opacity-100' : 'opacity-0'}`}>
                {t.saved}
                </span>
                <button 
                type="submit"
                className="px-6 py-2 bg-solutium-blue hover:bg-solutium-dark text-white font-medium rounded-lg shadow-sm transition-colors"
                >
                {t.save}
                </button>
            </div>
            </form>
        </div>
      )}

      {/* TEAM TAB */}
      {activeTab === 'team' && (
          <div className="space-y-6">
              {/* Add Member Form */}
              <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
                  <h3 className="text-lg font-bold text-slate-800 mb-2">{t.addMember}</h3>
                  <p className="text-slate-500 text-sm mb-4">{t.teamDesc}</p>
                  
                  {user?.subscriptionPlan === 'free' && (
                      <div className="bg-amber-50 border border-amber-200 text-amber-800 px-4 py-2 rounded text-sm mb-4">
                          {t.limitReached}
                      </div>
                  )}

                  <form onSubmit={handleAddMember} className="flex flex-col md:flex-row gap-4 items-end">
                      <div className="flex-1 w-full">
                          <Input label={t.memberName} value={newMemberName} onChange={(e) => setNewMemberName(e.target.value)} placeholder="Jane Doe" className="mb-0" />
                      </div>
                      <div className="flex-1 w-full">
                          <Input label={t.memberEmail} value={newMemberEmail} onChange={(e) => setNewMemberEmail(e.target.value)} placeholder="jane@company.com" type="email" className="mb-0" />
                      </div>
                      <button 
                        type="submit" 
                        disabled={user?.subscriptionPlan === 'free'}
                        className="px-6 py-2 bg-solutium-blue text-white rounded-lg font-medium hover:bg-solutium-dark disabled:opacity-50 disabled:cursor-not-allowed mb-[2px]"
                      >
                          {t.addMember}
                      </button>
                  </form>
                  {errorMsg && <p className="text-red-500 text-sm mt-2">{errorMsg}</p>}
              </div>

              {/* Members List */}
              <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
                  <table className="w-full text-left">
                      <thead className="bg-slate-50 text-slate-600 text-sm uppercase font-semibold">
                          <tr>
                              <th className="px-6 py-4">{t.memberName}</th>
                              <th className="px-6 py-4">{t.memberRole}</th>
                              <th className="px-6 py-4">{t.status}</th>
                              <th className="px-6 py-4 text-right">Actions</th>
                          </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100">
                          {user?.teamMembers.length === 0 ? (
                              <tr>
                                  <td colSpan={4} className="px-6 py-8 text-center text-slate-400 italic">
                                      {t.noMembers}
                                  </td>
                              </tr>
                          ) : (
                              user?.teamMembers.map((member: TeamMember) => (
                                  <tr key={member.id} className="hover:bg-slate-50 transition-colors">
                                      <td className="px-6 py-4">
                                          <div className="flex items-center">
                                              <div className="w-8 h-8 rounded-full bg-slate-200 flex items-center justify-center text-slate-500 font-bold mr-3">
                                                  {member.name.charAt(0)}
                                              </div>
                                              <div>
                                                  <p className="font-medium text-slate-900">{member.name}</p>
                                                  <p className="text-xs text-slate-500">{member.email}</p>
                                              </div>
                                          </div>
                                      </td>
                                      <td className="px-6 py-4">
                                          <span className="bg-blue-100 text-blue-800 text-xs px-2 py-1 rounded-full">{member.role}</span>
                                      </td>
                                      <td className="px-6 py-4">
                                          <span className="text-slate-600 text-sm capitalize">{member.status}</span>
                                      </td>
                                      <td className="px-6 py-4 text-right">
                                          <button 
                                            onClick={() => removeTeamMember(member.id)}
                                            className="text-red-500 hover:text-red-700 text-sm font-medium"
                                          >
                                              {t.delete}
                                          </button>
                                      </td>
                                  </tr>
                              ))
                          )}
                      </tbody>
                  </table>
              </div>
          </div>
      )}
    </div>
  );
};

export default Profile;