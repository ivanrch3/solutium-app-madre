import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { AVAILABLE_APPS } from '../constants';
import { ServiceApp } from '../types';
import { AppCardSkeleton, HeaderSkeleton } from '../components/SkeletonLoader';
import { encodeSolutiumToken, type SolutiumPayload } from '../utils/satelliteConnection';

const Dashboard: React.FC< { onNavigate: (tab: string) => void }> = ({ onNavigate }) => {
  const { user, currentProject, uninstallApp, t } = useAuth();
  const [isLoadingData, setIsLoadingData] = useState(true);
  
  // Filter apps based on CURRENT PROJECT
  const installedApps = AVAILABLE_APPS.filter(app => (currentProject?.installedAppIds || []).includes(app.id));

  useEffect(() => {
    // Reset loading when project changes
    setIsLoadingData(true);
    const timer = setTimeout(() => {
        setIsLoadingData(false);
    }, 600);
    return () => clearTimeout(timer);
  }, [currentProject?.id]);

  const handleLaunchApp = (app: ServiceApp) => {
    if (!user || !currentProject) return;

    // --- SECURITY HANDSHAKE PROTOCOL ---
    // 1. Prepare Payload
    const payload: SolutiumPayload = { 
      userId: user.id, 
      projectId: currentProject.id,
      role: user.role,
      projectData: {
          name: currentProject.name,
          colors: currentProject.brandColors || ['#333', '#fff', '#ccc'],
          logoUrl: currentProject.logoUrl || '',
          contact: {
              email: currentProject.email || '',
              phone: currentProject.whatsapp || '', 
              address: currentProject.address || ''
          }
      },
      timestamp: Date.now()
    };
    
    // 2. Encode Token
    const token = encodeSolutiumToken(payload);
    
    // 3. Launch Logic - REAL SATELLITE CONNECTION
    // We construct the URL with the token and open it in a new tab.
    // This assumes the Satellite App is running on the port defined in constants.tsx (e.g., 3001).
    
    const targetUrl = new URL(app.url);
    targetUrl.searchParams.append('token', token);
    targetUrl.searchParams.append('lang', user.language);
    
    console.log(`[Solutium Core] Launching External App: ${app.name} -> ${targetUrl.toString()}`);
    window.open(targetUrl.toString(), '_blank');
  };

  const handleUninstall = (e: React.MouseEvent, appId: string) => {
      e.stopPropagation();
      if(window.confirm("Are you sure you want to remove this app from this project?")) {
          uninstallApp(appId);
      }
  };

  if (isLoadingData) {
      return (
          <div className="space-y-8">
              <HeaderSkeleton />
              <div className="pt-4">
                 <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                     <AppCardSkeleton />
                     <AppCardSkeleton />
                 </div>
              </div>
          </div>
      );
  }

  if (!currentProject) {
      return <div>Please create a project to continue.</div>;
  }

  return (
    <div className="space-y-6 animate-fadeIn">
      <header className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
            <h2 className="text-3xl font-bold text-solutium-dark">
                {t.dashboard}
            </h2>
            <p className="text-solutium-grey mt-2 max-w-lg">{t.dashboardSubtitle}</p>
        </div>
    
      </header>

      <hr className="border-slate-200" />

      {/* My Apps Section */}
      <div>
        {installedApps.length === 0 ? (
            // Improved Empty State for Project
            <div className="bg-slate-50 border-2 border-dashed border-slate-300 rounded-xl p-12 flex flex-col items-center justify-center text-center">
                <div className="w-16 h-16 bg-slate-200 rounded-full flex items-center justify-center text-slate-400 mb-4">
                    <svg className="w-8 h-8" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10" /></svg>
                </div>
                <h4 className="text-lg font-bold text-solutium-dark mb-1">{t.noApps}</h4>
                <p className="text-solutium-grey mb-6 max-w-sm">{t.portfolioDesc}</p>
                <button 
                    onClick={() => onNavigate('portfolio')}
                    className="px-6 py-2 bg-solutium-blue text-white rounded-lg font-medium hover:bg-solutium-dark transition-colors"
                >
                    {t.goToPortfolio}
                </button>
            </div>
        ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {installedApps.map((app) => (
                <div key={app.id} className="bg-white rounded-xl shadow-sm hover:shadow-xl hover:-translate-y-1 transition-all duration-300 p-6 flex flex-col border border-slate-100 group relative">
                    
                    {/* Uninstall Button */}
                    <button 
                        onClick={(e) => handleUninstall(e, app.id)}
                        className="absolute top-4 right-4 text-slate-300 hover:text-red-500 transition-colors z-10"
                        title={t.uninstall}
                    >
                        <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg>
                    </button>

                    <div className="flex items-center space-x-4 mb-4">
                        <div className="p-3 bg-solutium-blue text-white rounded-lg shadow-md group-hover:bg-solutium-dark transition-colors">
                        {app.icon}
                        </div>
                        <div>
                        <h4 className="font-bold text-lg text-solutium-dark">{app.name}</h4>
                        <span className="text-xs bg-green-100 text-green-700 px-2 py-0.5 rounded-full font-medium">{t.installed}</span>
                        </div>
                    </div>
                    <p className="text-solutium-grey text-sm flex-1 mb-6 leading-relaxed">
                        {app.description}
                    </p>
                    
                    <button
                        onClick={() => handleLaunchApp(app)}
                        className="w-full py-2.5 px-4 bg-solutium-dark text-white rounded-lg font-medium hover:bg-solutium-blue transition-colors flex items-center justify-center space-x-2 shadow-md"
                    >
                        <span>{t.open}</span>
                        <svg className="w-4 h-4 text-solutium-yellow" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" />
                        </svg>
                    </button>
                </div>
            ))}
            
            {/* Add New App Card */}
            <button 
                onClick={() => onNavigate('portfolio')}
                className="rounded-xl border-2 border-dashed border-slate-200 hover:border-solutium-blue hover:bg-blue-50/30 transition-all p-6 flex flex-col items-center justify-center text-center h-full min-h-[250px] group"
            >
                 <div className="w-12 h-12 bg-white rounded-full shadow-sm flex items-center justify-center text-solutium-blue mb-4 group-hover:scale-110 transition-transform">
                     <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" /></svg>
                 </div>
                 <h4 className="font-bold text-slate-700">{t.installNew}</h4>
                 <p className="text-sm text-slate-400 mt-2">{t.portfolioDesc}</p>
            </button>
            </div>
        )}
      </div>
    </div>
  );
};

export default Dashboard;