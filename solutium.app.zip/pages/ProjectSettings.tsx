import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { Input } from '../components/Input';
import { TeamMember, SocialLink } from '../types';
import { extractPaletteFromImage } from '../utils/colorUtils';
import { Button } from '../components/Button'; // Import Button for modal

const ProjectSettings: React.FC = () => {
  const { currentProject, user, updateProject, toggleProjectMember, t, logout } = useAuth();
  
  // State for all fields
  const [name, setName] = useState('');
  
  // Logo
  const [logoMode, setLogoMode] = useState<'url' | 'upload'>('url');
  const [logoUrl, setLogoUrl] = useState('');
  
  // Colors (Array of 3)
  const [colors, setColors] = useState<string[]>(['#000000', '#000000', '#000000']);
  
  // WhatsApp
  const [countryCode, setCountryCode] = useState('+1');
  const [whatsAppNumber, setWhatsAppNumber] = useState('');
  
  // Web & Email
  const [website, setWebsite] = useState('');
  const [email, setEmail] = useState('');
  
  // Socials
  const [socials, setSocials] = useState<SocialLink[]>([]);
  
  // Address
  const [address, setAddress] = useState('');
  
  const [isSaved, setIsSaved] = useState(false);
  const [isDirty, setIsDirty] = useState(false);
  const [showMapModal, setShowMapModal] = useState(false);
  const [isExtracting, setIsExtracting] = useState(false);
  
  // NEW: Guest Warning Modal State
  const [showGuestWarning, setShowGuestWarning] = useState(false);

  // Set global dirty flag for Layout to check
  useEffect(() => {
      // @ts-ignore
      window.hasUnsavedChanges = isDirty;
  }, [isDirty]);

  useEffect(() => {
      if (currentProject) {
          setName(currentProject.name || '');
          setLogoUrl(currentProject.logoUrl || '');
          setColors(currentProject.brandColors && currentProject.brandColors.length === 3 
              ? currentProject.brandColors 
              : ['#005e79', '#ffffff', '#000000']);
          
          setWebsite(currentProject.website?.replace('https://', '') || '');
          setEmail(currentProject.email || '');
          setAddress(currentProject.address || '');
          
          if (currentProject.whatsapp) {
              const parts = currentProject.whatsapp.split(' ');
              if (parts.length > 1) {
                  setCountryCode(parts[0]);
                  setWhatsAppNumber(parts.slice(1).join(' '));
              } else {
                  setWhatsAppNumber(currentProject.whatsapp);
              }
          }

          setSocials(currentProject.socials || []);
          setIsDirty(false); // Reset dirty on load
      }
  }, [currentProject]);

  if (!currentProject) return null;

  const handleChange = (setter: React.Dispatch<any>, value: any) => {
      setter(value);
      setIsDirty(true);
      setIsSaved(false);
  };

  const handleColorChange = (index: number, val: string) => {
      const newColors = [...colors];
      newColors[index] = val;
      setColors(newColors);
      setIsDirty(true);
      setIsSaved(false);
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
      if (e.target.files && e.target.files[0]) {
          const file = e.target.files[0];
          // Validations
          if (!file.type.startsWith('image/')) {
              alert("Error: Solo se permiten archivos de imagen (JPG, PNG, GIF).");
              return;
          }
          if (file.size > 5 * 1024 * 1024) { // 5MB
              alert("Error: La imagen es demasiado pesada. El límite es 5MB.");
              return;
          }
          
          try {
              const url = URL.createObjectURL(file);
              handleChange(setLogoUrl, url);
          } catch (error) {
              console.error("Error creating object URL", error);
              alert("No se pudo procesar la imagen seleccionada.");
          }
      }
  };

  const generateFallbackColors = () => {
      // Deterministic fallback based on string hash for CORS blocked images
      let hash = 0;
      for (let i = 0; i < logoUrl.length; i++) hash = logoUrl.charCodeAt(i) + ((hash << 5) - hash);
      const c1 = "#" + ("00000" + ((hash * 123) & 0x00FFFFFF).toString(16)).substr(-6);
      const c2 = "#" + ("00000" + ((hash * 456) & 0x00FFFFFF).toString(16)).substr(-6);
      const c3 = "#" + ("00000" + ((hash * 789) & 0x00FFFFFF).toString(16)).substr(-6);
      
      setColors([c1, c2, c3]);
      setIsDirty(true);
  };

  const handleExtractColors = async () => {
      if (!logoUrl) return;
      setIsExtracting(true);

      try {
          // Attempt to use the robust canvas logic
          const extractedColors = await extractPaletteFromImage(logoUrl);

          if (extractedColors && extractedColors.length > 0) {
              // Fill with white if we got less than 3 colors
              const finalColors = [...extractedColors];
              while(finalColors.length < 3) {
                  finalColors.push('#FFFFFF');
              }
              setColors(finalColors.slice(0,3));
              setIsDirty(true);
          } else {
              // If empty array returned (CORS error inside utility), use fallback
              generateFallbackColors();
          }
      } catch (e) {
          console.error(e);
          generateFallbackColors();
      } finally {
          setIsExtracting(false);
      }
  };

  const handleAddSocial = () => {
      if (socials.length < 5) { 
          const newSocials = [...socials, { platform: 'facebook', username: '' }];
          // @ts-ignore
          setSocials(newSocials);
          setIsDirty(true);
      }
  };

  const handleSocialChange = (index: number, field: keyof SocialLink, value: string) => {
      const newSocials = [...socials];
      newSocials[index] = { ...newSocials[index], [field]: value };
      setSocials(newSocials);
      setIsDirty(true);
  };

  const handleRemoveSocial = (index: number) => {
      const newSocials = socials.filter((_, i) => i !== index);
      setSocials(newSocials);
      setIsDirty(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
      e.preventDefault();

      // INTERCEPT GUEST SAVE
      if (user?.role === 'guest') {
          setShowGuestWarning(true);
          return;
      }
      
      const fullWebsite = website ? `https://${website}` : '';
      
      updateProject(currentProject.id, {
          name,
          logoUrl,
          brandColors: colors,
          whatsapp: `${countryCode} ${whatsAppNumber}`,
          website: fullWebsite,
          email,
          address,
          socials
      });
      setIsSaved(true);
      setIsDirty(false);
      setTimeout(() => setIsSaved(false), 3000);
  };

  const handleGuestCreateAccount = () => {
      // Clear dirty flag so we can navigate
      // @ts-ignore
      window.hasUnsavedChanges = false;
      // Logout sends to Landing where they can Register
      logout();
  };

  const countryOptions = [
      { code: '+54', flag: '🇦🇷', name: 'Argentina' },
      { code: '+591', flag: '🇧🇴', name: 'Bolivia' },
      { code: '+55', flag: '🇧🇷', name: 'Brazil' },
      { code: '+56', flag: '🇨🇱', name: 'Chile' },
      { code: '+57', flag: '🇨🇴', name: 'Colombia' },
      { code: '+506', flag: '🇨🇷', name: 'Costa Rica' },
      { code: '+53', flag: '🇨🇺', name: 'Cuba' },
      { code: '+1', flag: '🇩🇴', name: 'Dom. Rep.' },
      { code: '+593', flag: '🇪🇨', name: 'Ecuador' },
      { code: '+503', flag: '🇸🇻', name: 'El Salvador' },
      { code: '+502', flag: '🇬🇹', name: 'Guatemala' },
      { code: '+504', flag: '🇭🇳', name: 'Honduras' },
      { code: '+52', flag: '🇲🇽', name: 'Mexico' },
      { code: '+505', flag: '🇳🇮', name: 'Nicaragua' },
      { code: '+507', flag: '🇵🇦', name: 'Panama' },
      { code: '+595', flag: '🇵🇾', name: 'Paraguay' },
      { code: '+51', flag: '🇵🇪', name: 'Peru' },
      { code: '+1', flag: '🇵🇷', name: 'Puerto Rico' },
      { code: '+1', flag: '🇺🇸', name: 'USA' },
      { code: '+598', flag: '🇺🇾', name: 'Uruguay' },
      { code: '+58', flag: '🇻🇪', name: 'Venezuela' },
      { code: '+34', flag: '🇪🇸', name: 'Spain' },
  ];

  const currentFlag = countryOptions.find(c => c.code === countryCode)?.flag || '🇺🇸';

  return (
    <div className="max-w-4xl mx-auto pb-12 animate-fadeIn relative">
        <header className="mb-8 border-b border-slate-200 pb-4">
          <h2 className="text-3xl font-bold text-solutium-dark">{t.projectSettings}</h2>
        </header>

        <form onSubmit={handleSubmit} className="space-y-8">
            
            {/* 1. Identity Card */}
            <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
                <h3 className="text-lg font-bold text-slate-800 mb-6 border-b border-slate-100 pb-2">{t.projIdentity}</h3>
                
                {/* HERO INPUT FOR PROJECT NAME */}
                <div className="mb-8">
                    <label className="block text-xs font-bold text-solutium-blue uppercase tracking-wider mb-2">
                        {t.labelProjectName}
                    </label>
                    <input 
                        type="text"
                        value={name}
                        onChange={(e) => handleChange(setName, e.target.value)}
                        placeholder={t.phProjectName}
                        className="block w-full text-3xl font-bold text-solutium-dark border-0 border-b-2 border-slate-200 focus:border-solutium-blue focus:ring-0 px-0 py-2 bg-transparent transition-all placeholder-slate-300"
                    />
                </div>

                {/* Logo & Colors Combined Section */}
                <div className="mb-6">
                    <label className="block text-sm font-medium text-slate-700 mb-2">{t.labelLogo}</label>
                    
                    {/* Buttons Above Preview */}
                    <div className="flex space-x-2 text-sm mb-2">
                        <button 
                            type="button" 
                            onClick={() => setLogoMode('url')}
                            className={`px-4 py-1.5 rounded-full font-medium transition-colors ${logoMode === 'url' ? 'bg-solutium-blue text-white' : 'bg-slate-100 text-slate-500 hover:bg-slate-200'}`}
                        >
                            URL
                        </button>
                        <button 
                            type="button" 
                            onClick={() => {
                                setLogoMode('upload');
                                handleChange(setLogoUrl, '');
                            }}
                            className={`px-4 py-1.5 rounded-full font-medium transition-colors ${logoMode === 'upload' ? 'bg-solutium-blue text-white' : 'bg-slate-100 text-slate-500 hover:bg-slate-200'}`}
                        >
                            {t.uploadImage}
                        </button>
                    </div>

                    <div className="flex flex-col md:flex-row gap-8">
                        {/* LEFT: Preview + Input */}
                        <div className="flex-1 space-y-3">
                            {/* Preview Area */}
                            <div className="w-full h-40 rounded-lg border-2 border-dashed border-slate-300 flex items-center justify-center bg-slate-50 overflow-hidden relative">
                                {logoUrl ? (
                                    <>
                                        <img src={logoUrl} alt="Logo" className="w-full h-full object-contain p-4" />
                                        {/* Delete Button */}
                                        <button
                                            type="button"
                                            onClick={(e) => {
                                                e.stopPropagation();
                                                handleChange(setLogoUrl, '');
                                            }}
                                            className="absolute top-2 right-2 p-1 bg-white rounded-full shadow-md text-slate-400 hover:text-red-500 hover:bg-red-50 transition-colors z-10"
                                            title={t.delete}
                                        >
                                            <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                                            </svg>
                                        </button>
                                    </>
                                ) : (
                                    <span className="text-slate-400 text-sm">{t.noLogo}</span>
                                )}
                            </div>
                            
                            {/* Inputs based on mode */}
                            {logoMode === 'url' ? (
                                <input 
                                    type="text" 
                                    placeholder={t.phUrl}
                                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm"
                                    value={logoUrl}
                                    onChange={(e) => handleChange(setLogoUrl, e.target.value)}
                                />
                            ) : (
                                <div className="flex items-center">
                                    <label className="w-full cursor-pointer bg-slate-100 border border-slate-300 rounded-lg px-4 py-2 text-sm font-medium hover:bg-slate-200 text-center text-slate-600 transition-colors">
                                        {t.uploadImage}
                                        <input 
                                            type="file" 
                                            className="hidden" 
                                            accept="image/png, image/jpeg, image/gif"
                                            onChange={handleImageUpload} 
                                        />
                                    </label>
                                </div>
                            )}
                        </div>
                        
                        {/* RIGHT: Color Palette */}
                        <div className="w-full md:w-48 flex flex-col">
                            <label className="block text-sm font-medium text-slate-700 mb-2">{t.labelColor}</label>
                            
                            <div className="flex flex-col space-y-3">
                                <div className="flex space-x-2">
                                    {colors.map((color, idx) => (
                                        <div key={idx} className="flex flex-col items-center">
                                            <div className="w-12 h-12 rounded-full border border-slate-200 overflow-hidden shadow-sm relative group cursor-pointer">
                                                <input 
                                                    type="color" 
                                                    value={color}
                                                    onChange={(e) => handleColorChange(idx, e.target.value)}
                                                    className="absolute inset-0 w-[150%] h-[150%] -top-[25%] -left-[25%] p-0 border-0 cursor-pointer"
                                                />
                                            </div>
                                            <span className="text-[10px] text-slate-500 mt-1 uppercase font-mono">{color}</span>
                                        </div>
                                    ))}
                                </div>
                                
                                <button 
                                    type="button"
                                    onClick={handleExtractColors}
                                    disabled={!logoUrl || isExtracting || logoMode === 'url'}
                                    className="mt-2 w-full py-2 px-3 border border-slate-300 rounded-lg text-xs font-medium text-slate-600 hover:bg-slate-50 disabled:opacity-50 transition-colors"
                                >
                                    {isExtracting ? '...' : t.extractColors}
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            {/* 2. Contact Card */}
            <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
                 <h3 className="text-lg font-bold text-slate-800 mb-6 border-b border-slate-100 pb-2">{t.projContact}</h3>
                 
                 {/* WhatsApp - STRICTLY FLAG + CODE */}
                 <div className="mb-4">
                    <label className="block text-sm font-medium text-slate-700 mb-1">{t.labelWhatsApp}</label>
                    <div className="flex relative">
                        {/* Visual representation */}
                        <div className="absolute left-0 top-0 bottom-0 min-w-[5rem] px-3 bg-slate-50 border border-slate-300 rounded-l-lg flex items-center justify-center text-sm z-0">
                            <span className="mr-2 text-lg">{currentFlag}</span>
                            <span className="text-slate-600 font-medium">{countryCode}</span>
                        </div>

                        {/* Transparent Select */}
                        <select 
                            value={countryCode}
                            onChange={(e) => handleChange(setCountryCode, e.target.value)}
                            className="h-full px-2 py-2 opacity-0 cursor-pointer z-10 absolute left-0 min-w-[5rem]"
                        >
                            {countryOptions.map(opt => (
                                <option key={opt.code} value={opt.code}>{opt.flag} {opt.name} ({opt.code})</option>
                            ))}
                        </select>
                        
                        {/* Input pushed right */}
                        <div className="flex-1 flex ml-[5rem]">
                            <input 
                                type="tel"
                                value={whatsAppNumber}
                                onChange={(e) => handleChange(setWhatsAppNumber, e.target.value)}
                                placeholder="999 999 9999"
                                className="flex-1 px-4 py-2 border border-slate-300 rounded-r-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                            />
                        </div>
                    </div>
                 </div>

                 {/* Website */}
                 <div className="mb-4">
                    <label className="block text-sm font-medium text-slate-700 mb-1">{t.labelWebsite}</label>
                    <div className="flex items-center">
                        <span className="bg-slate-100 border border-slate-300 border-r-0 rounded-l-lg px-3 py-2 text-slate-500 text-sm">https://</span>
                        <input 
                            type="text"
                            value={website}
                            onChange={(e) => handleChange(setWebsite, e.target.value)}
                            onBlur={() => {
                                if (website && !email) {
                                    const domain = website.split('/')[0];
                                    handleChange(setEmail, `contact@${domain}`);
                                }
                            }}
                            placeholder={t.phWebsite}
                            className="flex-1 px-4 py-2 border border-slate-300 rounded-r-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                        />
                    </div>
                 </div>

                 {/* Email */}
                 <Input 
                    label={t.labelEmail} 
                    value={email} 
                    onChange={(e) => handleChange(setEmail, e.target.value)} 
                    type="email"
                    placeholder={t.phEmail}
                 />
            </div>

            {/* 3. Social Media Card */}
            <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
                <div className="flex justify-between items-center mb-6 border-b border-slate-100 pb-2">
                    <h3 className="text-lg font-bold text-slate-800">{t.projSocial}</h3>
                    {socials.length < 5 && (
                         <button type="button" onClick={handleAddSocial} className="text-xs bg-slate-100 hover:bg-slate-200 text-slate-700 px-3 py-1 rounded-full font-medium">
                             + {t.addSocial}
                         </button>
                    )}
                </div>
                
                <div className="space-y-4">
                    {socials.length === 0 && <p className="text-sm text-slate-400 italic">No social media added.</p>}
                    
                    {socials.map((social, index) => (
                        <div key={index} className="flex gap-2 items-center">
                            <select
                                value={social.platform}
                                onChange={(e) => handleSocialChange(index, 'platform', e.target.value as any)}
                                className="w-32 px-2 py-2 border border-slate-300 rounded-lg text-sm bg-slate-50"
                            >
                                <option value="facebook">Facebook</option>
                                <option value="instagram">Instagram</option>
                                <option value="x">X (Twitter)</option>
                                <option value="linkedin">LinkedIn</option>
                                <option value="tiktok">TikTok</option>
                            </select>
                            
                            <div className="flex-1 flex items-center relative">
                                <span className="absolute left-3 text-slate-400 text-xs pointer-events-none">
                                    {social.platform === 'facebook' && 'facebook.com/'}
                                    {social.platform === 'instagram' && 'instagram.com/'}
                                    {social.platform === 'x' && 'x.com/'}
                                    {social.platform === 'linkedin' && 'linkedin.com/in/'}
                                    {social.platform === 'tiktok' && 'tiktok.com/@'}
                                </span>
                                <input 
                                    type="text"
                                    value={social.username}
                                    onChange={(e) => handleSocialChange(index, 'username', e.target.value)}
                                    className="w-full pl-28 px-3 py-2 border border-slate-300 rounded-lg text-sm"
                                    placeholder={t.phUser}
                                />
                            </div>
                            <button type="button" onClick={() => handleRemoveSocial(index)} className="text-red-400 hover:text-red-600">
                                <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
                            </button>
                        </div>
                    ))}
                </div>
            </div>

            {/* 4. Location Card (Fixed Embed URL) */}
            <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
                <h3 className="text-lg font-bold text-slate-800 mb-6 border-b border-slate-100 pb-2">{t.projLocation}</h3>
                
                <div className="flex gap-2 mb-4">
                     <div className="flex-1">
                        <Input 
                            label={t.labelAddress} 
                            value={address} 
                            onChange={(e) => handleChange(setAddress, e.target.value)}
                            placeholder="123 Market St, San Francisco, CA"
                            className="mb-0"
                        />
                     </div>
                     <div className="flex items-end mb-4">
                        <button 
                            type="button" 
                            onClick={() => {
                                if(address) setShowMapModal(true);
                            }}
                            disabled={!address}
                            className="h-[42px] px-4 bg-white border border-slate-300 text-slate-700 rounded-lg hover:bg-slate-50 disabled:opacity-50 whitespace-nowrap"
                        >
                            {t.viewOnMap}
                        </button>
                     </div>
                </div>
            </div>

            {/* 5. Team Assignment */}
            <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
                <h3 className="text-lg font-bold text-slate-800 mb-2">{t.projTeam}</h3>
                <p className="text-sm text-slate-500 mb-4">{t.projTeamDesc}</p>
                
                <div className="max-h-64 overflow-y-auto space-y-2">
                    {user?.teamMembers.length === 0 ? (
                        <p className="text-sm text-slate-400 italic p-4 text-center border border-dashed rounded">
                            {t.projTeamEmptyHint}
                        </p>
                    ) : (
                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                        {user?.teamMembers.map((member: TeamMember) => {
                            const isAssigned = currentProject.assignedMemberIds?.includes(member.id);
                            return (
                                <div key={member.id} className="flex items-center justify-between p-3 rounded-lg border border-slate-100 hover:border-blue-200 transition-colors">
                                    <div className="flex items-center">
                                        <div className="w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center text-xs font-bold mr-3">
                                            {member.name.charAt(0)}
                                        </div>
                                        <div className="overflow-hidden">
                                            <p className="text-sm font-medium truncate w-24">{member.name}</p>
                                            <p className="text-xs text-slate-500">{member.role}</p>
                                        </div>
                                    </div>
                                    <button 
                                        type="button"
                                        onClick={() => toggleProjectMember(currentProject.id, member.id)}
                                        className={`text-xs px-2 py-1 rounded font-medium transition-colors ${
                                            isAssigned 
                                            ? 'bg-red-50 text-red-600 hover:bg-red-100' 
                                            : 'bg-green-50 text-green-600 hover:bg-green-100'
                                        }`}
                                    >
                                        {isAssigned ? t.removeFromProject : t.assignToProject}
                                    </button>
                                </div>
                            );
                        })}
                        </div>
                    )}
                </div>
            </div>

            {/* Save Button */}
            <div className="flex items-center justify-between pt-4 sticky bottom-4 bg-slate-50/90 backdrop-blur p-4 rounded-xl border border-white shadow-lg z-20">
                <span className={`text-sm text-green-600 font-medium transition-opacity ${isSaved ? 'opacity-100' : 'opacity-0'}`}>
                    {t.saved}
                </span>
                <button type="submit" className="px-8 py-3 bg-solutium-blue text-white rounded-lg hover:bg-solutium-dark font-bold shadow-lg transform active:scale-95 transition-all">
                    {t.save}
                </button>
            </div>

        </form>

        {/* GOOGLE MAPS EMBED MODAL */}
        {showMapModal && (
            <div className="fixed inset-0 z-50 bg-slate-900/80 backdrop-blur-sm flex items-center justify-center p-4">
                <div className="bg-white rounded-xl shadow-2xl max-w-4xl w-full p-4 h-[80vh] flex flex-col">
                    <div className="flex justify-between items-center mb-4">
                        <h3 className="text-lg font-bold text-slate-900">{t.mapModalTitle}</h3>
                        <button onClick={() => setShowMapModal(false)} className="text-slate-400 hover:text-slate-600">✕</button>
                    </div>
                    
                    <div className="flex-1 bg-slate-100 rounded-lg overflow-hidden border border-slate-200">
                        {/* Using standard legacy embed url which works better without API KEY for demos */}
                        <iframe 
                            width="100%" 
                            height="100%" 
                            style={{border:0}} 
                            loading="lazy" 
                            allowFullScreen 
                            src={`https://maps.google.com/maps?q=${encodeURIComponent(address)}&t=&z=13&ie=UTF8&iwloc=&output=embed`}
                        ></iframe>
                    </div>
                    
                    <div className="mt-4 flex justify-between items-center">
                        <span className="text-sm text-slate-500">
                            Showing result for: <strong>{address}</strong>
                        </span>
                        <button 
                            onClick={() => setShowMapModal(false)}
                            className="px-6 py-2 bg-solutium-blue text-white rounded-lg hover:bg-solutium-dark"
                        >
                            {t.confirmLocation}
                        </button>
                    </div>
                </div>
            </div>
        )}

        {/* GUEST SAVE WARNING MODAL */}
        {showGuestWarning && (
            <div className="fixed inset-0 z-[70] bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4">
                <div className="bg-white rounded-xl shadow-2xl max-w-sm w-full p-8 animate-scaleIn border-t-4 border-solutium-blue">
                    <div className="flex flex-col items-center text-center mb-6">
                        <div className="w-12 h-12 bg-blue-100 text-solutium-blue rounded-full flex items-center justify-center mb-4">
                            <svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                            </svg>
                        </div>
                        <h3 className="text-xl font-bold text-solutium-dark">
                            {t.guestSaveTitle}
                        </h3>
                        <p className="text-slate-500 text-sm mt-2 leading-relaxed">
                            {t.guestSaveMsg}
                        </p>
                    </div>
                    
                    <div className="flex flex-col space-y-3">
                        <Button 
                            variant="primary"
                            onClick={handleGuestCreateAccount}
                            className="w-full justify-center"
                            size="lg"
                        >
                            {t.guestCreateAccount}
                        </Button>
                        <Button 
                            variant="ghost"
                            onClick={() => setShowGuestWarning(false)}
                            className="w-full justify-center text-slate-400 hover:text-slate-600"
                            size="md"
                        >
                            {t.cancel}
                        </Button>
                    </div>
                </div>
            </div>
        )}
    </div>
  );
};

export default ProjectSettings;