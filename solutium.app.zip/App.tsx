import React, { useState, useEffect } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import Layout from './components/Layout';
import Landing from './pages/Landing';
import Dashboard from './pages/Dashboard';
import Profile from './pages/Profile';
import TechRoadmap from './pages/TechRoadmap';
import AdminConsole from './pages/AdminConsole';
import OnboardingWizard from './components/OnboardingWizard';
import Portfolio from './pages/Portfolio';
import ProjectSettings from './pages/ProjectSettings';
import InvoicerApp from './pages/InvoicerApp'; // NEW

const AuthenticatedApp: React.FC = () => {
  // Initialize from local storage or default to dashboard
  const [currentTab, setCurrentTab] = useState(() => {
      return localStorage.getItem('solutium_active_tab') || 'dashboard';
  });
  const { user } = useAuth();

  useEffect(() => {
     // Check if specific redirect pending from Onboarding
     const redirect = localStorage.getItem('solutium_redirect');
     if (redirect) {
         setCurrentTab(redirect);
         localStorage.setItem('solutium_active_tab', redirect);
         localStorage.removeItem('solutium_redirect');
     }
  }, []);

  const handleNavigate = (tab: string) => {
      setCurrentTab(tab);
      localStorage.setItem('solutium_active_tab', tab);
  };

  // Redirect new users to the Onboarding Wizard
  if (user && !user.onboardingCompleted) {
      return <OnboardingWizard onNavigate={handleNavigate} />;
  }

  // --- SPECIAL ROUTE FOR SATELLITE APP SIMULATION ---
  // If we are in the Invoicer Demo, we render it full screen (no Layout)
  // to simulate it being a completely separate application.
  if (currentTab === 'invoicer-demo') {
      return <InvoicerApp onExit={() => handleNavigate('dashboard')} />;
  }

  const renderContent = () => {
    switch (currentTab) {
      case 'dashboard':
        return <Dashboard onNavigate={handleNavigate} />;
      case 'portfolio':
        return <Portfolio />;
      case 'profile':
        return <Profile />;
      case 'project-settings':
        return <ProjectSettings />;
      case 'tech-roadmap':
        return <TechRoadmap />;
      case 'admin-console':
        return user?.role === 'admin' ? <AdminConsole /> : <Dashboard onNavigate={handleNavigate} />;
      default:
        return <Dashboard onNavigate={handleNavigate} />;
    }
  };

  return (
    <Layout activeTab={currentTab} onNavigate={handleNavigate}>
      {renderContent()}
    </Layout>
  );
};

const Main: React.FC = () => {
  const { user, isLoading } = useAuth();

  if (isLoading) {
    return (
      <div className="h-screen flex items-center justify-center bg-slate-50">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-solutium-blue"></div>
      </div>
    );
  }

  return user ? <AuthenticatedApp /> : <Landing />;
};

const App: React.FC = () => {
  return (
    <AuthProvider>
      <Main />
    </AuthProvider>
  );
};

export default App;