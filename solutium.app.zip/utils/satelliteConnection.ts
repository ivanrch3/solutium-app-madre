/**
 * SOLUTIUM SATELLITE RECEIVER KIT
 * --------------------------------
 * Copia este archivo en tu aplicación "Satélite" (Cotizador, Web Builder, etc.)
 * para permitir que se conecte con la App Madre.
 */

export interface SolutiumPayload {
  userId: string;
  projectId: string;
  role: string;
  projectData?: {
      name: string;
      colors: string[];
      logoUrl: string;
      contact: {
          email: string;
          phone: string;
          address: string;
      }
  };
  timestamp: number;
}

/**
 * COMPATIBLE BASE64 ENCODER
 * Uses encodeURIComponent to handle UTF-8 safely in all environments (including sandboxes)
 */
const utf8_to_b64 = (str: string): string => {
    try {
        return window.btoa(encodeURIComponent(str).replace(/%([0-9A-F]{2})/g,
            function toSolidBytes(_match, p1) {
                return String.fromCharCode(parseInt(p1, 16));
            }));
    } catch (e) {
        console.error("Encoding failed:", e);
        return "";
    }
};

/**
 * COMPATIBLE BASE64 DECODER
 */
const b64_to_utf8 = (str: string): string => {
    try {
        return decodeURIComponent(Array.prototype.map.call(window.atob(str), function(c: string) {
            return '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2);
        }).join(''));
    } catch (e) {
        console.warn("Decoding failed:", e);
        return "";
    }
};

/**
 * Codifica el payload de forma segura.
 */
export const encodeSolutiumToken = (payload: SolutiumPayload): string => {
    try {
        const jsonString = JSON.stringify(payload);
        return utf8_to_b64(jsonString);
    } catch (e) {
        console.error("Error preparing token:", e);
        return "";
    }
};

/**
 * Decodifica el token de forma segura.
 */
const decodeSolutiumToken = (token: string): SolutiumPayload | null => {
    if (!token) return null;
    
    try {
        const jsonString = b64_to_utf8(token);
        if (!jsonString) return null;
        return JSON.parse(jsonString) as SolutiumPayload;
    } catch (e) {
        console.error("Error parsing token JSON:", e);
        return null;
    }
};

/**
 * ESTRATEGIA DE CONEXIÓN ROBUSTA
 * 1. Busca 'solutium_sim_token' en sessionStorage (Puente para Simulador Local).
 * 2. Busca '?token=' en la URL (Producción).
 * 3. Busca 'solutium_session_token' (Persistencia tras recarga).
 */
export const connectToSolutium = (): SolutiumPayload | null => {
    try {
        // PRIORIDAD 1: Puente del Simulador (Evita problemas de URL en Sandboxes)
        const simToken = sessionStorage.getItem('solutium_sim_token');
        if (simToken) {
            const payload = decodeSolutiumToken(simToken);
            if (payload) return payload;
        }

        // PRIORIDAD 2: URL (Producción / Subdominios)
        const params = new URLSearchParams(window.location.search);
        const tokenFromUrl = params.get('token');

        if (tokenFromUrl) {
            const payload = decodeSolutiumToken(tokenFromUrl);
            
            if (payload) {
                // Guardar en sesión para navegación interna
                try {
                    sessionStorage.setItem('solutium_session_token', tokenFromUrl);
                    
                    // Intentar limpiar URL (silencioso si falla)
                    const newUrl = window.location.protocol + "//" + window.location.host + window.location.pathname;
                    window.history.replaceState({path: newUrl}, '', newUrl);
                } catch (e) {
                    // Ignorar errores de history en entornos restringidos
                }

                return payload;
            }
        }

        // PRIORIDAD 3: Persistencia
        try {
            const storedToken = sessionStorage.getItem('solutium_session_token');
            if (storedToken) {
                return decodeSolutiumToken(storedToken);
            }
        } catch (e) {
            // Ignore
        }

        return null;
    } catch (e) {
        console.error("Solutium Connection Critical Failure:", e);
        return null;
    }
};